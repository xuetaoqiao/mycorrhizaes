# Shared settings for v2_public_anonymized/code. Every script sources this file first.
# It defines where the data are, where results go, and paper2_events(), which reads the deposited event
# table and adds the variable names used by the scripts (all are exact transformations of deposited columns).
# Optional: set the environment variables PAPER2_EVENTS (another copy of the event table) and PAPER2_OUT
# (another output folder), for example to run this code on the v1_current_full data for comparison.
suppressPackageStartupMessages(library(data.table))
if (!exists("here")) stop("Set `here` (the folder of the calling script) before sourcing 00_config.R.")
PAPER2_ROOT <- normalizePath(file.path(here, "..", ".."))                # this package (v2_public_anonymized)
DATA_DIR <- file.path(PAPER2_ROOT, "data")
EVENTS_FILE <- Sys.getenv("PAPER2_EVENTS", file.path(DATA_DIR, "paper2_drought_events_anonymized.csv.gz"))
OUT_DIR <- Sys.getenv("PAPER2_OUT", file.path(PAPER2_ROOT, "output"))
out_dir <- function(...) { d <- file.path(OUT_DIR, ...); dir.create(d, recursive = TRUE, showWarnings = FALSE); d }
N_WORKERS <- max(1L, min(11L, parallel::detectCores() - 1L))              # parallel workers for Figure 5; results do not depend on this

paper2_events <- function(file = EVENTS_FILE) {
  D <- fread(file, colClasses = c(event_ID = "character", plot_ID = "character",
                                  type_group = "character", mycorrhizal_type = "character"))
  stopifnot(nrow(D) == 363085L, uniqueN(D$plot_ID) == 83092L, !anyDuplicated(D$event_ID))
  # Mycorrhizal type: EcM basal area >= 95% (EcM-dominant), <= 5% (AM-dominant), otherwise Mixed
  D[, type := fifelse(EcM_percent >= 95, "EcM", fifelse(EcM_percent <= 5, "AM", "Mixed EcM and AM"))]
  stopifnot(all(D[, (type == "AM") == (mycorrhizal_type == "AM-dominant") & (type == "EcM") == (mycorrhizal_type == "EcM-dominant")]))
  D[, `:=`(Rs_log = log2(resistance), species_richness_log = log2(q0), EcM_percentage = EcM_percent,
           STDAGE = stand_age_years, DENSITY = density_ha, SLOPE = slope_percent, ELEV = elevation_m, SPEI = SPEI_Oct06)]
  D[]
}
