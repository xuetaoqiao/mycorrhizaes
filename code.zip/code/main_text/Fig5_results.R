#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 5 and Supporting Information Figs S6-S8
# Results only: computes every estimate of Figure 5 and of its supplements (Figs S6 to S8) and writes them to output/main_text/Fig5/tables/.
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig5_1_estimates.R (the code used for the paper); the calculations are unchanged.
Sys.setenv(VECLIB_MAXIMUM_THREADS='1',OMP_NUM_THREADS='1')
suppressPackageStartupMessages({library(data.table);library(MASS);library(parallel);library(splines);library(metafor)})
setDTthreads(2);options(width=230)
script<-normalizePath(gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE));here<-dirname(script)
source(file.path(here,'..','00_config.R'))   # upload package: data and output locations
out<-out_dir('main_text','Fig5');dir.create(file.path(out,'tables'),showWarnings=FALSE);root<-PAPER2_ROOT
lib<-file.path(here,'Fig5_lib.R');source(lib)
SOIL_COVARIATES<-character()
soil<-c('z_clay','z_bulk','z_totaln','z_ph');base_z<-setdiff(zvars,soil);zvars<-c(base_z,SOIL_COVARIATES);soil<-character();formals(fe_ols)$cluster<-'plot_ID'   # [Upload package] no soil variables in the deposited data
wt<-function(x,n)fwrite(as.data.table(x),file.path(out,'tables',paste0(n,'.csv')),na='NA')
MIN_N<-1L
F4<-paper2_events()[,.(event_ID,type)]
A<-load_events(root,primary=FALSE);A[,event_ID:=as.character(event_ID)];A<-merge(A,F4,by='event_ID');stopifnot(nrow(A)==363085L)
if('z_sm'%in%zvars){SM<-fread(file.path(out,'data/plot_soil_moisture.csv.gz'),colClasses=c(plot_ID='character'));A<-merge(A,SM[,.(plot_ID,sm)],by='plot_ID',all.x=TRUE,sort=FALSE);stopifnot(nrow(A)==363085L,all(is.finite(A$sm)));ib<-A[,q0>=2&phylo_complete%in%TRUE&is.finite(MPD)];stopifnot(sum(ib)==238411L);A[,z_sm:=(sm-mean(sm[ib]))/sd(sm[ib])]}
A[,ty:=fifelse(EcM_percent>=95,'EcM',fifelse(EcM_percent<=5,'AM','Mixed'))];stopifnot(A[,all(ty==fifelse(type=='Mixed EcM and AM','Mixed',type))])
A[,`:=`(gE=as.numeric(ty=='EcM'),gM=as.numeric(ty=='Mixed'),p=EcM_percent/100,clade=as.character(clade))]
A[,both:=E>1e-9&Am>1e-9]
A[,ex:=paste(q0,round(MPD,3))]
A[,`:=`(g90E=as.numeric(EcM_percent>=90),g90M=as.numeric(EcM_percent>10&EcM_percent<90),g80E=as.numeric(EcM_percent>=80),g80M=as.numeric(EcM_percent>20&EcM_percent<80))]
A[,gM2:=as.numeric(ty=='Mixed'&both)];A[,gO:=as.numeric(ty=='Mixed'&!both)]
A[,tyB:=fifelse(ty=='Mixed'&!both,'Other',ty)];A[,ty90:=fifelse(g90E==1,'EcM',fifelse(g90M==1,'Mixed','AM'))];A[,ty80:=fifelse(g80E==1,'EcM',fifelse(g80M==1,'Mixed','AM'))]
A[,tyS:=fifelse(cls=='EcM','EcM',fifelse(cls=='AM','AM',fifelse(cls=='MixedHosts','Mixed','Other')))]
spc<-grep('^sp_',names(A),value=TRUE)
keep<-c('plot_ID','year','eco','q0','MPD','MPD_bin25','SRxMPD','ex','r','mu','y',zvars,soil,'ty','gE','gM','p','clade','east','D','both','phylo_complete','type_group','g90E','g90M','g80E','g80M','gM2','gO','tyB','ty90','ty80','tyS','g_EcM','gT','gDO','gDE','gDA',spc)
keep<-unique(keep);A<-A[,..keep]
A[,mpd_ok:=phylo_complete%in%TRUE&is.finite(MPD)];stopifnot(nrow(A)==363085L,A[ty!='Mixed',max(q0)]==8L,A[ty=='Mixed',range(q0)]==c(2L,14L))
sup_q<-A[,.(events=.N,plots=uniqueN(plot_ID)),keyby=.(q0,ty)];sup_q_c<-A[mpd_ok==TRUE,.(events=.N,plots=uniqueN(plot_ID)),keyby=.(q0,ty)];wt(rbind(sup_q[,sample:='Total data'],sup_q_c[,sample:='Complete host phylogeny']),'support_by_richness')
lev_ok<-function(d,tv,classes=c('AM','EcM','Mixed')){x<-dcast(d[get(tv)%in%classes,.N,by=c('q0',tv)],as.formula(paste('q0~',tv)),value.var='N',fill=0L);m<-x[,do.call(pmin,.SD),.SDcols=classes];x$q0[m>=MIN_N]}
lv<-lev_ok(A,'ty');cat('levels with all three classes present:',lv,'\n');stopifnot(identical(as.integer(lv),2:8));lvB<-lev_ok(A[mpd_ok==TRUE],'ty');cat('with phylogeny:',lvB,'\n');stopifnot(identical(as.integer(lvB),2:8))
PA<-A[q0>=1];PB<-A[q0>=2&mpd_ok==TRUE];P1<-A[q0>=2]
samp<-rbind(data.table(sample='A: total data',events=nrow(PA),plots=uniqueN(PA$plot_ID)),data.table(sample='B: A with complete host phylogeny',events=nrow(PB),plots=uniqueN(PB$plot_ID)),data.table(sample='A without monocultures',events=nrow(P1),plots=uniqueN(P1$plot_ID)));print(samp);wt(samp,'sample_sizes')
wt(rbind(PA[,.(sample='A',events=.N,plots=uniqueN(plot_ID)),keyby=ty],PB[,.(sample='B',events=.N,plots=uniqueN(plot_ID)),keyby=ty]),'class_support')
wt(PB[,.(events=.N),keyby=.(ty,clade,MPD_bin25)],'MPD_hist_by_class_clade')
wt(A[,.(events=.N,conifer_pct=100*mean(clade=='Conifer'),broadleaf_pct=100*mean(clade=='Angiosperm'),both_pct=100*mean(clade=='Conifer+angio')),keyby=.(q0,ty)],'composition_by_richness')
wt(PB[,.(events=.N,q10=quantile(MPD,.1),q50=median(MPD),q90=quantile(MPD,.9),lt100=100*mean(MPD<100)),keyby=ty],'MPD_by_class')
HOST<-list(x=c('gE','gM'),con=list(`EcM vs AM`=c(gE=1),`Mixed vs AM`=c(gM=1),`Mixed vs EcM`=c(gM=1,gE=-1)))
FE_EY<-c('eco','year')
fitall<-function(d,extra=NULL,fe=list(FE_EY),keep=TRUE)list(h=fe_ols(d,'y',c(HOST$x,extra),fe=fe,keep_scores=keep))
effs<-function(F,tag)rbindlist(lapply(names(HOST$con),function(k)cbind(tag,data.table(contrast=k,N=F$h$N),lincom(F$h,HOST$con[[k]]))))
diffs<-function(F1,F0,tag)rbindlist(lapply(names(HOST$con),function(k)cbind(tag,data.table(contrast=k),diff_two(F1$h,HOST$con[[k]],F0$h,HOST$con[[k]]))))
txt<-function(d)d[,txt:=sprintf('%+.3f[%+.3f,%+.3f]',estimate,lower,upper)]
cl<-makePSOCKcluster(N_WORKERS);clusterExport(cl,c('lib','MIN_N','A','HOST','FE_EY','fitall','effs','diffs','spc'));invisible(clusterEvalQ(cl,{suppressPackageStartupMessages({library(data.table);library(MASS);library(splines)});setDTthreads(1);source(lib);NULL}));clusterExport(cl,c('zvars','soil','base_z','fe_ols'))
pm<-function(X,FUN,vars=character()){if(length(vars))clusterExport(cl,vars);parLapplyLB(cl,X,FUN,chunk.size=1)}
sets<-function(s)switch(s,A=A[q0>=1],B=A[q0>=2&mpd_ok==TRUE],A2=A[q0>=2])
wk<-list(S1=list(l='All stands, without richness',s='A',x=NULL,fe=list(FE_EY)),S2=list(l='All stands, + richness',s='A',x=NULL,fe=list(FE_EY,'q0')),S3=list(l='Complete phylogeny, + richness',s='B',x=NULL,fe=list(FE_EY,'q0')),S4=list(l='Complete phylogeny, + richness + MPD',s='B',x='mu',fe=list(FE_EY,'q0')))
Rw0<-pm(names(wk),function(k){S<-wk[[k]];list(k=k,F=fitall(sets(S$s),c(S$x,zvars),S$fe))},c('wk','sets'));RF<-setNames(lapply(Rw0,`[[`,'F'),vapply(Rw0,`[[`,'',1))
WK<-rbindlist(lapply(names(wk),function(k)effs(RF[[k]],data.table(step=k,label=wk[[k]]$l))));wt(WK,'control_walk');print(dcast(txt(WK),contrast~step,value.var='txt'))
WC<-rbind(diffs(RF$S2,RF$S1,data.table(change='Add richness')),diffs(RF$S4,RF$S3,data.table(change='Add MPD')));WC<-merge(WC,rbind(WK[step=='S1',.(change='Add richness',contrast,base=estimate)],WK[step=='S3',.(change='Add MPD',contrast,base=estimate)]),by=c('change','contrast'));WC[,pct:=100*estimate/base];wt(WC,'control_walk_change');print(WC[,.(change,contrast,est=round(estimate,3),lo=round(lower,3),hi=round(upper,3),p=signif(p,2),pct=round(pct,1))]);flush.console()
jt<-function(f,v,lab){b<-names(f$b);H<-do.call(rbind,lapply(v,function(k){z<-setNames(numeric(length(b)),b);z[k]<-1;z}));colnames(H)<-b;cbind(data.table(model=lab),wald_test(f,H))}
JT<-rbind(jt(RF$S4$h,c('gE','gM'),'EcM + Mixed classes | richness + MPD + environment'),jt(RF$S2$h,c('gE','gM'),'EcM + Mixed classes | richness + environment, all stands'));wt(JT,'joint_type_test');print(JT)
Ja<-CJ(env=c(TRUE,FALSE),sp=c('base','S','MPD','both'),sorted=FALSE);sp4<-list(base=list(x=NULL,fe=list(FE_EY)),S=list(x=NULL,fe=list(FE_EY,'q0')),MPD=list(x='mu',fe=list(FE_EY)),both=list(x='mu',fe=list(FE_EY,'q0')))
Ra<-pm(seq_len(nrow(Ja)),function(i){j<-Ja[i];S<-sp4[[j$sp]];list(k=paste(j$env,j$sp),F=fitall(sets('B'),c(S$x,if(j$env)zvars),S$fe))},c('Ja','sp4','sets'));RA<-setNames(lapply(Ra,`[[`,'F'),vapply(Ra,`[[`,'',1))
AT<-rbindlist(lapply(seq_len(nrow(Ja)),function(i){j<-Ja[i];effs(RA[[paste(j$env,j$sp)]],data.table(environment=j$env,spec=j$sp))}));wt(AT,'attenuation_B');ATC<-rbindlist(lapply(c(TRUE,FALSE),function(e)rbind(diffs(RA[[paste(e,'S')]],RA[[paste(e,'base')]],data.table(environment=e,change='Add richness')),diffs(RA[[paste(e,'both')]],RA[[paste(e,'S')]],data.table(environment=e,change='Add MPD, given richness')))));b0<-rbind(AT[spec=='base',.(environment,change='Add richness',contrast,base=estimate)],AT[spec=='S',.(environment,change='Add MPD, given richness',contrast,base=estimate)]);ATC<-merge(ATC,b0,by=c('environment','change','contrast'));ATC[,pct:=100*estimate/base];wt(ATC,'attenuation_B_change');print(ATC[,.(environment,change,contrast,est=round(estimate,3),lo=round(lower,3),hi=round(upper,3),pct=round(pct,1))]);flush.console()
sub_list<-list(All=quote(rep(TRUE,.N)),East=quote(east==TRUE),West=quote(east==FALSE),`Conifer only`=quote(clade=='Conifer'),`Conifer + broadleaf`=quote(clade=='Conifer+angio'),`Broadleaf only`=quote(clade=='Angiosperm'))
Rd<-pm(names(sub_list),function(k){d<-sets('B');d<-d[eval(sub_list[[k]])];d[,`:=`(mu_AM=mu*(ty=='AM'),mu_Mix=mu*(ty=='Mixed'),mu_EcM=mu*(ty=='EcM'))];f<-fe_ols(d,'y',c('gE','gM','mu_AM','mu_Mix','mu_EcM',zvars),fe=list(FE_EY,'q0'));ct<-list(`AM`=c(mu_AM=1),`Mixed`=c(mu_Mix=1),`EcM`=c(mu_EcM=1),`Mixed - AM`=c(mu_Mix=1,mu_AM=-1),`EcM - AM`=c(mu_EcM=1,mu_AM=-1),`Mixed - EcM`=c(mu_Mix=1,mu_EcM=-1));rbindlist(lapply(names(ct),function(n)cbind(data.table(subset=k,term=n,N=f$N),lincom(f,ct[[n]]))))},c('sub_list','sets'));MS<-rbindlist(Rd);wt(MS,'mpd_slope_within_class');print(dcast(txt(MS),subset~term,value.var='txt'))
Rpm<-pm(c('AM','Mixed','EcM'),function(g){d<-sets('B');st<-d[,.(nt=uniqueN(ty)),by=plot_ID];d<-merge(d,st,by='plot_ID')[nt==1&ty==g];ch<-d[,.(ch=uniqueN(round(MPD,3))>1),by=plot_ID][ch==TRUE,.N];f<-fe_ols(d,'y',c('r','mu',zvars),fe=list('plot_ID',FE_EY));cbind(data.table(type=g,N=f$N,plots=uniqueN(d$plot_ID),MPD_changers=ch),lincom(f,c(mu=1)))},'sets');WM<-rbindlist(Rpm);wt(WM,'within_plot_MPD');print(WM[,.(type,N,plots,MPD_changers,est=round(estimate,3),lo=round(lower,3),hi=round(upper,3),p=signif(p,2))])
sdv<-PB[,.(gE=sd(gE),gM=sd(gM),r=sd(r),mu=sd(mu))];cors<-PB[,.(Mixed_MPD=cor(gM,mu),EcM_MPD=cor(gE,mu),Mixed_richness=cor(gM,r),EcM_richness=cor(gE,r),richness_MPD=cor(r,mu))];wt(cors,'predictor_correlations');print(cors)
Rz<-pm(c(TRUE,FALSE),function(e){f<-fe_ols(sets('B'),'y',c('gE','gM','r','mu',if(e)zvars),fe=list(FE_EY));rbindlist(lapply(names(sdv),function(k)cbind(data.table(environment=e,term=k,sd=sdv[[k]]),lincom(f,setNames(1,k)))))},c('sets','sdv'));SZ<-rbindlist(Rz);SZ[,`:=`(perSD=estimate*sd,perSD_lower=lower*sd,perSD_upper=upper*sd,pct=100*(2^(estimate*sd)-1))];wt(SZ,'sizes_per_SD');print(SZ[,.(environment,term,perSD=round(perSD,4),lo=round(perSD_lower,4),hi=round(perSD_upper,4),pct=round(pct,2),p=signif(p,2))]);flush.console()
Jl<-CJ(ss=c('All','East'),samp=c('A'),sorted=FALSE)
need<-list(`EcM vs AM`=c('AM','EcM'),`Mixed vs AM`=c('AM','Mixed'),`Mixed vs EcM`=c('EcM','Mixed'))
level_fit<-function(d,tag){levs<-sort(unique(d$q0));tb<-d[,.N,by=.(q0,ty)];d<-copy(d);out<-list();for(def in 'h'){S<-HOST;cols<-character();for(l in levs)for(t in S$x){if(t=='gM'&&l==1)next;nm<-paste0(t,'__L',l);set(d,j=nm,value=d[[t]]*(d$q0==l));cols<-c(cols,nm)}
  f<-fe_ols(d,'y',c(cols,zvars),fe=list(FE_EY,'q0'));for(k in names(S$con))for(l in levs){h<-S$con[[k]];names(h)<-paste0(names(h),'__L',l);nd<-need[[k]];mn<-if(all(nd%in%tb[q0==l,ty]))tb[q0==l&ty%in%nd,min(N)]else 0L;r<-if(all(names(h)%in%names(f$b)))lincom(f,h)else data.table(estimate=NA_real_,SE=NA_real_,lower=NA_real_,upper=NA_real_,p=NA_real_);out[[length(out)+1L]]<-cbind(tag,data.table(q0=l,contrast=k,min_events=mn,pass=mn>=MIN_N),r)}
  for(k in names(S$con)){use<-intersect(2:8,levs);use<-use[sapply(use,function(l){nd<-need[[k]];all(nd%in%tb[q0==l,ty])&&tb[q0==l&ty%in%nd,min(N)]>=MIN_N})];if(length(use)<3)next;H<-do.call(rbind,lapply(use,function(l){h<-S$con[[k]];names(h)<-paste0(names(h),'__L',l);v<-setNames(numeric(length(f$b)),names(f$b));v[names(h)]<-h;v}));Rm<-H[-1,,drop=FALSE]-matrix(H[1,],nrow(H)-1,ncol(H),byrow=TRUE);colnames(Rm)<-names(f$b);out[[length(out)+1L]]<-NULL;attr(out,'eq')<-c(attr(out,'eq'),list(cbind(tag,data.table(contrast=k,levels=paste(use,collapse=',')),wald_test(f,Rm))))}}
 list(lw=rbindlist(out),eq=rbindlist(attr(out,'eq')))}
clusterExport(cl,c('need','level_fit','Jl'))
RL<-pm(seq_len(nrow(Jl)),function(i){j<-Jl[i];d<-sets(j$samp);d<-switch(j$ss,All=d,East=d[east==TRUE]);level_fit(d,data.table(subset=j$ss))})
LW<-rbindlist(lapply(RL,`[[`,'lw'));EQ<-rbindlist(lapply(RL,`[[`,'eq'));wt(LW,'levelwise_richness');wt(EQ,'levelwise_equality_tests')
print(dcast(LW[subset=='All'][,txt:=sprintf('%+.2f[%+.2f,%+.2f]%s',estimate,lower,upper,ifelse(pass,'','x'))],contrast~q0,value.var='txt'));flush.console()
Js<-rbind(CJ(ss=c('All','East'),samp='A',mpdctl='none',sorted=FALSE),data.table(ss='All',samp='A2',mpdctl='none'),data.table(ss='All',samp='B',mpdctl=c('none','linear','cells')))
Rs<-pm(seq_len(nrow(Js)),function(i){j<-Js[i];d<-copy(sets(j$samp));d<-switch(j$ss,All=d,East=d[east==TRUE]);for(t in c('gE','gM'))set(d,j=paste0(t,'_r'),value=d[[t]]*d$r)
 fe<-if(j$mpdctl=='cells')list(FE_EY,'SRxMPD')else list(FE_EY,'q0');m0<-if(j$mpdctl=='linear')'mu'else NULL
 f1<-fe_ols(d,'y',c('gE','gM','gE_r','gM_r',m0,zvars),fe=fe)
 r<-list(`EcM vs AM`=lincom(f1,c(gE_r=1)),`Mixed vs AM`=lincom(f1,c(gM_r=1)),`Mixed vs EcM`=lincom(f1,c(gM_r=1,gE_r=-1)))
 rbindlist(lapply(names(r),function(k)cbind(j,data.table(contrast=k,N=f1$N),r[[k]])))},c('Js','sets'))
SL<-rbindlist(Rs);wt(SL,'slopes_richness');print(dcast(SL[,txt:=sprintf('%+.3f[%+.3f,%+.3f] p=%.2g',estimate,lower,upper,p)],ss+samp+mpdctl~contrast,value.var='txt'));flush.console()
Jw<-data.table(set=c('All stands','Without monocultures'))
Rw<-pm(seq_len(nrow(Jw)),function(i){st<-Jw$set[i];d0<-if(st=='All stands')A[q0>=1]else A[q0>=2];stab<-d0[,.(nt=uniqueN(ty),changed=uniqueN(q0)>1),by=plot_ID];PW<-merge(d0,stab,by='plot_ID');PW<-PW[nt==1];tys<-c('AM','EcM','Mixed')
 W<-rbindlist(lapply(tys,function(g){d<-PW[ty==g];f<-fe_ols(d,'y',c('r',zvars),fe=list('plot_ID',FE_EY));cbind(data.table(set=st,type=g,N=f$N,plots=uniqueN(d$plot_ID),changers=d[changed==TRUE,uniqueN(plot_ID)]),lincom(f,c(r=1)))}))
 dd<-copy(PW);dd[,`:=`(gE_r=gE*r,gM_r=gM*r)];fi<-fe_ols(dd,'y',c('r','gE_r','gM_r',zvars),fe=list('plot_ID',FE_EY));cons<-list(`EcM vs AM`=c(gE_r=1),`Mixed vs AM`=c(gM_r=1),`Mixed vs EcM`=c(gM_r=1,gE_r=-1));I<-rbindlist(lapply(cons,function(h)lincom(fi,h)),idcol='contrast');I[,`:=`(set=st,p_Holm=p.adjust(p,'holm'))];list(W=W,I=I)},'Jw')
WP<-rbindlist(lapply(Rw,`[[`,'W'));WI<-rbindlist(lapply(Rw,`[[`,'I'));wt(WP,'within_plot_slopes');wt(WI,'within_plot_interaction');print(WI[,.(set,contrast,est=round(estimate,3),lo=round(lower,3),hi=round(upper,3),p=signif(p,2),p_Holm=signif(p_Holm,2))]);flush.console()
adf<-list(dom95=list(tv='ty',e='gE',m='gM',x=NULL,lab='>=95% (main)'),dom95both=list(tv='tyB',e='gE',m='gM2',x='gO',lab='>=95%, Mixed with both host types'),dom90=list(tv='ty90',e='g90E',m='g90M',x=NULL,lab='>=90%'),dom80=list(tv='ty80',e='g80E',m='g80M',x=NULL,lab='>=80%'),strict=list(tv='tyS',e='g_EcM',m='gT',x=c('gDO','gDE','gDA'),lab='0%, 100%, both host types'))
sup_d<-rbindlist(lapply(names(adf),function(n)data.table(definition=n,label=adf[[n]]$lab,levels='total data')));wt(sup_d,'alternative_definitions_levels');print(sup_d)
Jad<-CJ(def=names(adf),kind=c('main','slope'),sorted=FALSE)
Rad<-pm(seq_len(nrow(Jad)),function(i){j<-Jad[i];a<-adf[[j$def]];d<-copy(A);e<-a$e;m<-a$m;d[,er:=get(e)*r];d[,mr:=get(m)*r]
 con<-list(`EcM vs AM`=setNames(1,e),`Mixed vs AM`=setNames(1,m),`Mixed vs EcM`=setNames(c(1,-1),c(m,e)));conr<-list(`EcM vs AM`=c(er=1),`Mixed vs AM`=c(mr=1),`Mixed vs EcM`=c(mr=1,er=-1))
 f<-switch(j$kind,main=fe_ols(d,'y',c(e,m,a$x,zvars),fe=list(FE_EY,'q0')),slope=fe_ols(d,'y',c(e,m,a$x,'er','mr',zvars),fe=list(FE_EY,'q0')))
 cc<-if(j$kind=='slope')conr else con;rbindlist(lapply(names(cc),function(k)cbind(data.table(definition=j$def,label=a$lab,levels='total data',kind=j$kind,contrast=k,N=f$N),lincom(f,cc[[k]]))))},c('adf','Jad','sup_d'))
AD<-rbindlist(Rad);wt(AD,'alternative_definitions');print(dcast(AD[,txt:=sprintf('%+.3f[%+.3f,%+.3f]',estimate,lower,upper)],contrast+kind~definition,value.var='txt'));flush.console()
z4<-c('z_age','z_slope','z_elev','z_pre','z_tem')
soil_name<-c(z_sm='soil moisture',z_totaln='soil nitrogen')
sv<-list()   # [Upload package] the two soil variants are not fitted, because the paper uses no soil variables
Jv<-data.table(v=c('Main','Eastern US','Western US','Figure 4 covariates (5)','No density','Without monocultures','+ Forest type group','+ 80 tree species',names(sv)))
Rvv<-pm(seq_len(nrow(Jv)),function(i){v<-Jv$v[i];d<-sets('A');x<-zvars;fe<-list(FE_EY,'q0');if(v=='Eastern US')d<-d[east==TRUE];if(v=='Western US')d<-d[east==FALSE];if(v=='Figure 4 covariates (5)')x<-z4;if(v=='No density')x<-setdiff(zvars,'z_density');if(v=='Without monocultures')d<-d[q0>=2];if(v=='+ Forest type group')fe<-list(FE_EY,'q0','type_group');if(v=='+ 80 tree species')x<-c(zvars,spc);if(v%in%names(sv))x<-sv[[v]];F<-fitall(d,x,fe,keep=FALSE);effs(F,data.table(variant=v))},c('Jv','spc','sets','z4','sv'));VA<-rbindlist(Rvv);wt(VA,'variants');print(dcast(VA[,txt:=sprintf('%+.3f[%+.3f,%+.3f]',estimate,lower,upper)],variant~contrast,value.var='txt'));flush.console()
mfit<-function(e,s)metafor::rma(yi=e,sei=s,method='REML',test='knha',control=list(maxiter=1000,stepadj=.5))
ECO<-rbindlist(pm(sort(unique(PA$eco)),function(e){d<-sets('A')[eco==e];n<-d[,.N,by=ty];g<-function(t)if(t%in%n$ty)n[ty==t,N]else 0L;res<-list();if(min(g('AM'),g('EcM'),g('Mixed'))>=100){f<-fe_ols(d,'y',c('gE','gM',zvars),fe=list('year','q0'));res<-lapply(names(HOST$con),function(k)cbind(data.table(eco=e,contrast=k),lincom(f,HOST$con[[k]])));dd<-copy(d);dd[,`:=`(gE_r=gE*r,gM_r=gM*r)];f3<-fe_ols(dd,'y',c('gE','gM','gE_r','gM_r',zvars),fe=list('year','q0'));res[[4]]<-cbind(data.table(eco=e,contrast='EcM vs AM, slope'),lincom(f3,c(gE_r=1)));res[[5]]<-cbind(data.table(eco=e,contrast='Mixed vs AM, slope'),lincom(f3,c(gM_r=1)));res[[6]]<-cbind(data.table(eco=e,contrast='Mixed vs EcM, slope'),lincom(f3,c(gM_r=1,gE_r=-1)))};rbindlist(res)},c('sets','HOST')));wt(ECO,'ecoregion_effects')
ME<-ECO[is.finite(SE)&SE>0&SE<3];MM<-ME[,{m<-mfit(estimate,SE);.(k=.N,pooled=as.numeric(m$beta),lower=m$ci.lb,upper=m$ci.ub,p=m$pval,I2=m$I2,n_pos=sum(estimate>0),n_neg=sum(estimate<0))},by=contrast];wt(MM,'ecoregion_meta');print(MM);flush.console()
ms<-list(M0=list(l='Without MPD',x=NULL,fe='q0'),M1=list(l='+ MPD, linear',x='mu',fe='q0'),M2=list(l='+ MPD, spline',x=paste0('ns',1:5),fe='q0'),M3=list(l='+ MPD, 25 Myr classes',x=NULL,fe=list('q0','MPD_bin25')),M4=list(l='Same richness, same 25 Myr class',x=NULL,fe='SRxMPD'),M5=list(l='Same richness, identical MPD',x=NULL,fe='ex'))
Rm<-pm(names(ms),function(k){d<-copy(sets('B'));nsm<-ns(d$MPD,df=5);for(i in 1:5)set(d,j=paste0('ns',i),value=nsm[,i]);S<-ms[[k]];list(k=k,F=fitall(d,c(S$x,zvars),c(list(FE_EY),as.list(S$fe))))},c('ms','sets'));MF<-setNames(lapply(Rm,`[[`,'F'),vapply(Rm,`[[`,'',1))
MP<-rbindlist(lapply(names(ms),function(k)effs(MF[[k]],data.table(spec=k,label=ms[[k]]$l))));wt(MP,'mpd_flexible_controls');print(dcast(txt(MP),contrast~spec,value.var='txt'))
ident<-function(v){x<-dcast(PB[,.N,by=c(v,'ty')],as.formula(paste(v,'~ty')),value.var='N',fill=0L);data.table(cell=v,cells=nrow(x),EcM_with_AM=x[EcM>0&AM>0,sum(EcM)],Mixed_with_AM=x[Mixed>0&AM>0,sum(Mixed)],EcM_with_Mixed=x[Mixed>0&EcM>0,sum(EcM)],all_AM=PB[ty=='AM',.N],all_EcM=PB[ty=='EcM',.N],all_Mixed=PB[ty=='Mixed',.N])};wt(rbind(ident('SRxMPD'),ident('ex')),'mpd_cell_identification')
Rsp<-pm(names(sub_list)[1:3],function(k){d<-sets('B');d<-d[eval(sub_list[[k]])];d[,`:=`(gEl=as.numeric(ty=='EcM'&MPD<100),gEh=as.numeric(ty=='EcM'&MPD>=100))];f<-fe_ols(d,'y',c('gEl','gEh','gM',zvars),fe=list(FE_EY,'q0'));ct<-list(`EcM <100 vs AM`=c(gEl=1),`EcM >=100 vs AM`=c(gEh=1),`Mixed vs AM`=c(gM=1),`Mixed vs EcM <100`=c(gM=1,gEl=-1),`Mixed vs EcM >=100`=c(gM=1,gEh=-1),`EcM >=100 vs EcM <100`=c(gEh=1,gEl=-1));o<-rbindlist(lapply(names(ct),function(n)cbind(data.table(subset=k,term=n),lincom(f,ct[[n]]))));cbind(o,d[,.(AM=sum(ty=='AM'),EcM_low=sum(gEl),EcM_high=sum(gEh),Mixed=sum(ty=='Mixed'))])},c('sub_list','sets'));SP<-rbindlist(Rsp);wt(SP,'EcM_split_by_MPD');print(dcast(txt(SP),term~subset,value.var='txt'))
wt(PB[ty=='EcM',.(events=.N,plots=uniqueN(plot_ID),east_pct=100*mean(east),conifer_pct=100*mean(clade=='Conifer'),both_pct=100*mean(clade=='Conifer+angio'),MPD_median=median(MPD)),keyby=.(group=fifelse(MPD<100,'EcM <100','EcM >=100'))],'EcM_groups_composition')
NE<-rbindlist(lapply(c(650.1,253.646),function(v){d<-PB[q0==2&round(MPD,3)==v&D<1e-9];F<-fitall(d,zvars,list(FE_EY),keep=FALSE);cbind(effs(F,data.table(MPD=v)),d[,.(AM=sum(ty=='AM'),EcM=sum(ty=='EcM'),Mixed=sum(ty=='Mixed'),plots_AM=uniqueN(plot_ID[ty=='AM']),plots_EcM=uniqueN(plot_ID[ty=='EcM']),plots_Mixed=uniqueN(plot_ID[ty=='Mixed']))])}));wt(NE,'natural_experiment_same_MPD');print(NE[,.(MPD,contrast,N,AM,EcM,Mixed,est=round(estimate,3),lo=round(lower,3),hi=round(upper,3),p=signif(p,2))])
stopCluster(cl);cat('COMPLETE\n')
