#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 4b,c and Table S7
# Results only: fits the four multivariable mixed models of Figure 4b,c and writes coefficients, VIFs and diagnostics.
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig4_2_panels_b_c_models.R (the code used for the paper); the calculations are unchanged.
suppressPackageStartupMessages({library(data.table);library(lme4);library(car);library(digest);library(jsonlite)})
setDTthreads(4)
script<-normalizePath(gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE));here<-dirname(script)
source(file.path(here,'..','00_config.R'))   # upload package: data and output locations
out<-out_dir('main_text','Fig4');dir.create(file.path(out,'tables'),showWarnings=FALSE)
P<-paper2_events()[,.(event_ID,plot_ID,year,eco,q0,type,resistance,Rs_log,species_richness_log,STDAGE,DENSITY,SLOPE,ELEV,pre,tem,SPEI)]
stopifnot(nrow(P)==363085L,!anyDuplicated(P$event_ID))
P[,`:=`(EcM_dominant=as.numeric(type=='EcM'),Mixed_type=as.numeric(type=='Mixed EcM and AM'))]
soil<-c('ph','totaln','bulk','clay')
base<-c('species_richness_log','STDAGE','DENSITY','SLOPE','ELEV','pre','tem','SPEI')
total<-c('species_richness_log','EcM_dominant','Mixed_type','STDAGE','DENSITY','SLOPE','ELEV','pre','tem','SPEI')
old<-data.table(type=character(),variable=character(),estimate=numeric(),SE=numeric(),lower95=numeric(),upper95=numeric(),p_Wald=numeric(),driver=character(),label=character())
lab<-data.table(variable=c('species_richness_log','EcM_dominant','Mixed_type','STDAGE','SLOPE','ELEV','pre','tem','DENSITY','SPEI'),
 driver=c('Species richness','Mycorrhizas','Mycorrhizas','Stand age and density','Geographical attributes','Geographical attributes','Climatic conditions','Climatic conditions','Stand age and density','Climatic conditions'),
 label=c('Species richness','EcM-dominant (vs AM-dominant)','Mixed (vs AM-dominant)','Stand age','Slope','Elevation','May-Oct precipitation','May-Oct temperature','Stand density','Drought intensity (SPEI)'))
types<-c('Total','EcM','AM','Mixed EcM and AM');groups<-c('Climatic conditions','Geographical attributes','Stand age and density','Species richness','Mycorrhizas')
CO<-SCALE<-DIAG<-list();wt<-function(x,n)fwrite(x,file.path(out,'tables',paste0(n,'.csv')),na='NA')
for(t in types){
 d<-if(t=='Total')copy(P)else copy(P[type==t]);preds<-if(t=='Total')total else base;vars<-c('Rs_log',preds);stopifnot(!any(soil%in%preds))
 ss<-data.table(type=t,variable=vars,center=vapply(vars,function(v)mean(d[[v]]),0),SD=vapply(vars,function(v)sd(d[[v]]),0))
 stopifnot(all(ss$SD>0),all(is.finite(as.matrix(d[,..vars]))));for(i in seq_len(nrow(ss)))set(d,j=ss$variable[i],value=(d[[ss$variable[i]]]-ss$center[i])/ss$SD[i])
 d[,`:=`(eco_f=factor(eco),plot_f=factor(plot_ID),year_f=factor(year))]
 f<-reformulate(c(preds,'(1|eco_f)','(1|plot_f)','(1|year_f)'),response='Rs_log');environment(f)<-globalenv()
 ww<-character();wh<-function(w){ww<<-c(ww,conditionMessage(w));invokeRestart('muffleWarning')}
 m<-withCallingHandlers(lmer(f,data=d,REML=TRUE,control=lmerControl(optimizer='nloptwrap',calc.derivs=TRUE,optCtrl=list(maxeval=200000,xtol_abs=1e-10,ftol_abs=1e-10))),warning=wh)
 H<-m@optinfo$derivs$Hessian;g<-m@optinfo$derivs$gradient
 if(max(abs(solve(chol(H),g)))>=.002){ww<-character();m<-withCallingHandlers(lmer(f,data=d,REML=TRUE,start=list(theta=getME(m,'theta')),control=lmerControl(optimizer='bobyqa',calc.derivs=TRUE,optCtrl=list(maxfun=200000,rhoend=1e-9))),warning=wh);H<-m@optinfo$derivs$Hessian;g<-m@optinfo$derivs$gradient}
 # results only: the fitted model objects are not saved
 b<-fixef(m);se<-sqrt(diag(as.matrix(vcov(m))));X<-getME(m,'X')
 z<-data.table(type=t,variable=names(b),estimate=unname(b),SE=unname(se),lower95=unname(b-1.96*se),upper95=unname(b+1.96*se),p_Wald=2*pnorm(-abs(b/se)))[variable!='(Intercept)']
 z<-merge(z,lab,by='variable',all.x=TRUE,sort=FALSE);setcolorder(z,names(old));stopifnot(!anyNA(z$driver));CO[[t]]<-z;SCALE[[t]]<-ss
 vi<-car::vif(m);vx<-diag(solve(cor(X[,-1,drop=FALSE])));vc<-as.data.frame(VarCorr(m));vf<-var(drop(X%*%b));vr<-sum(vc$vcov[vc$grp!='Residual']);ve<-sigma(m)^2
 DIAG[[t]]<-data.table(type=t,events=nrow(d),plots=uniqueN(d$plot_ID),optimizer_code=paste(m@optinfo$conv$opt,collapse=';'),singular=isSingular(m),
  Hessian_min=min(eigen(H,symmetric=TRUE,only.values=TRUE)$values),max_scaled_gradient=max(abs(solve(chol(H),g))),normal_equation=max(abs(crossprod(X,residuals(m))))/nrow(d),
  maximum_VIF=max(vi),maximum_design_VIF=max(vx),marginal_R2=vf/(vf+vr+ve),conditional_R2=(vf+vr)/(vf+vr+ve),warnings=paste(ww,collapse=' | '),
  messages=paste(m@optinfo$conv$lme4$messages,collapse=' | '),reused_from=NA_character_,formula=paste(deparse(f),collapse=' '))
 wt(data.table(type=t,variable=names(vi),VIF=unname(vi)),paste0(gsub(' ','_',t),'_VIF'));wt(data.table(type=t,variable=names(vx),VIF=unname(vx)),paste0(gsub(' ','_',t),'_design_VIF'))
 cat(t,'n=',nrow(d),'\n');flush.console()
}
co<-rbindlist(CO);stopifnot(nrow(co)==34L)
rel<-co[,.(mean_absolute_beta=mean(abs(estimate)),number_of_predictors=.N),by=.(type,driver)];rel[,relative_effect_percent:=100*mean_absolute_beta/sum(mean_absolute_beta),by=type]
cells<-merge(CJ(type=types,driver=groups,unique=TRUE),rel,by=c('type','driver'),all.x=TRUE);cells[,estimable:=!is.na(relative_effect_percent)]
dd<-rbindlist(DIAG);stopifnot(all(dd$optimizer_code=='0'),!any(dd$singular),all(dd$Hessian_min>0),all(dd$max_scaled_gradient<.002),all(dd$normal_equation<1e-8))
wt(co,'panel_c_standardized_coefficients');wt(rel,'panel_b_relative_effects');wt(cells,'panel_b_all_driver_cells');wt(rbindlist(SCALE),'standardization_reference');wt(dd,'model_diagnostics')
print(co[,.(type,variable,estimate,lower95,upper95,p_Wald)]);print(rel);print(dd[,.(type,max_scaled_gradient,maximum_VIF,maximum_design_VIF,warnings)]);cat('COMPLETE\n')
