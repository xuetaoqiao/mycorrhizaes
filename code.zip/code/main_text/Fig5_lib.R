# paper2 upload package v2_public_anonymized: functions for Figure 5
# Results only: fixed-effects OLS by alternating projections with plot-clustered (CR1) covariance, and helpers.
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig5_lib.R (the code used for the paper); the calculations are unchanged.
suppressPackageStartupMessages({library(data.table)})
make_id<-function(d,vars){
 if(length(vars)==1)return(as.integer(factor(d[[vars]])))
 as.integer(factor(do.call(paste,c(lapply(vars,function(v)d[[v]]),sep='|'))))
}
demean<-function(M,ids,w=NULL,tol=1e-7,maxit=3000){
 if(!length(ids))return(M)
 den<-lapply(ids,function(g)if(is.null(w))tabulate(g)else as.numeric(rowsum(w,g,reorder=TRUE)))
 for(it in seq_len(maxit)){
  M0<-if(length(ids)>1)M else NULL
  for(j in seq_along(ids)){
   g<-ids[[j]]
   s<-rowsum(if(is.null(w))M else M*w,g,reorder=TRUE)/den[[j]]
   M<-M-s[g,,drop=FALSE]
  }
  if(length(ids)==1)break
  if(max(abs(M-M0))<tol)break
 }
 attr(M,'iter')<-it;M
}
fe_ols<-function(d,y,x,fe=list(),cluster='block100',weights=NULL,keep_resid=FALSE,keep_scores=FALSE){
 Y<-d[[y]];X<-as.matrix(d[,..x]);storage.mode(X)<-'double'
 ok<-is.finite(Y)&rowSums(!is.finite(X))==0
 w<-if(is.null(weights))NULL else d[[weights]]
 if(!all(ok)){stop('Non-finite values in ',y,' or X: ',sum(!ok))}
 ids<-lapply(fe,function(v)make_id(d,v))
 M<-cbind(Y,X);colnames(M)[1]<-'..y'
 if(!length(ids)){
  ids<-list(rep(1L,nrow(M)))
 }
 D<-demean(M,ids,w=w)
 Yt<-D[,1];Xt<-D[,-1,drop=FALSE]
 sw<-if(is.null(w))1 else sqrt(w)
 Xs<-Xt*sw;Ys<-Yt*sw
 orig_sd<-apply(X,2,sd);keep0<-apply(Xs,2,function(z)sqrt(mean(z^2)))>1e-6*pmax(orig_sd,1e-12)
 scl<-apply(Xs,2,function(z)sqrt(mean(z^2)));scl[scl==0]<-1
 q<-qr(sweep(Xs[,keep0,drop=FALSE],2,scl[keep0],'/'),tol=1e-8);rk<-q$rank
 keep<-which(keep0)[sort(q$pivot[seq_len(rk)])]
 dropped<-colnames(Xt)[setdiff(seq_len(ncol(Xt)),keep)]
 Xk<-Xs[,keep,drop=FALSE]
 sc0<-scl[keep];Xz<-sweep(Xk,2,sc0,'/');XtXz<-crossprod(Xz)
 bz<-tryCatch(chol2inv(chol(XtXz)),error=function(e)MASS::ginv(XtXz))
 bread<-sweep(sweep(bz,1,sc0,'/'),2,sc0,'/')
 b<-drop(bread%*%crossprod(Xk,Ys));names(b)<-colnames(Xk)
 u<-Ys-drop(Xk%*%b)
 clf<-factor(d[[cluster]]);cl<-as.integer(clf);G<-max(cl)
 sc<-rowsum(Xk*u,cl,reorder=TRUE)
 N<-nrow(Xk);K<-ncol(Xk)
 V<-bread%*%crossprod(sc)%*%bread*(G/(G-1))*((N-1)/(N-K));dimnames(V)<-list(names(b),names(b))
 out<-list(b=b,V=V,G=G,N=N,K=K,df=G-1,dropped=dropped,r2_within=1-sum(u^2)/sum(Ys^2),sst=sum(Ys^2),iter=attr(D,'iter'),
  n_plots=if('plot_ID'%in%names(d))uniqueN(d$plot_ID)else NA_integer_)
 if(keep_resid)out$resid<-u
 if(keep_scores){rownames(sc)<-levels(clf);colnames(sc)<-names(b);dimnames(bread)<-list(names(b),names(b));out$sc<-sc;out$bread<-bread}
 out
}
lincom<-function(f,h){
 nm<-names(f$b);hv<-setNames(numeric(length(nm)),nm)
 if(!all(names(h)%in%nm))return(data.table(estimate=NA_real_,SE=NA_real_,lower=NA_real_,upper=NA_real_,p=NA_real_))
 hv[names(h)]<-h
 e<-sum(hv*f$b);se<-sqrt(drop(t(hv)%*%f$V%*%hv));cr<-qt(.975,f$df)
 data.table(estimate=e,SE=se,lower=e-cr*se,upper=e+cr*se,p=2*pt(-abs(e/se),f$df))
}
wald_test<-function(f,H){
 nm<-names(f$b);R<-matrix(0,nrow(H),length(nm),dimnames=list(NULL,nm))
 if(!all(colnames(H)%in%nm))return(data.table(F=NA_real_,df1=NA_integer_,df2=NA_real_,p=NA_real_))
 R[,colnames(H)]<-H
 e<-drop(R%*%f$b);W<-R%*%f$V%*%t(R);rk<-qr(W,tol=1e-10)$rank
 stat<-drop(t(e)%*%MASS::ginv(W)%*%e)
 data.table(F=stat/rk,df1=rk,df2=f$df,p=pf(stat/rk,rk,f$df,lower.tail=FALSE))
}
add_dummies<-function(d){
 d[,`:=`(g_EcM=as.numeric(guild=='EcM'),g_Mix=as.numeric(guild=='Mixed'),
         d_EcM=as.numeric(dom80=='EcMdom'),d_Mid=as.numeric(dom80=='Mid'),
         d9_EcM=as.numeric(dom90=='EcMdom'),d9_Mid=as.numeric(dom90=='Mid'))]
 invisible(d)
}
zvars<-c('z_age','z_density','z_slope','z_elev','z_pre','z_tem','z_clay','z_bulk','z_totaln','z_ph','z_SPEI')

load_events<-function(root,primary=TRUE){
 # [Upload package] events_all.rds is rebuilt from the deposited event table; every column below is an exact
 # transformation of deposited columns (checked against events_all.rds when the upload package was built)
 A<-paper2_events();A[,type:=NULL]
 A[,`:=`(y=log2(resistance),r=log2(q0)-1,mu=(MPD-300)/100,p_ecm=EcM_percent/100,MPD_bin25=floor(MPD/25),
         signed_relative_anomaly=(NDVI-normal_NDVI)/normal_NDVI,
         guild=factor(fifelse(EcM_percent==100,'EcM',fifelse(EcM_percent==0,'AM','Mixed'))),
         dom80=factor(fifelse(EcM_percent>=80,'EcMdom',fifelse(EcM_percent<=20,'AMdom','Mid'))),
         dom90=factor(fifelse(EcM_percent>=90,'EcMdom',fifelse(EcM_percent<=10,'AMdom','Mid'))),
         clade=factor(fifelse(conifer_share==1,'Conifer',fifelse(conifer_share==0,'Angiosperm','Conifer+angio'))))]
 A<-add_dummies(A)
 A[,D:=dual_BA_percent/100];A[,E:=pmax(p_ecm-.5*D,0)];A[,Am:=pmax(1-E-D,0)]
 tol<-1e-9
 A[,cls:=fifelse(g_EcM==1,'EcM',fifelse(g_Mix==0,'AM',fifelse(E>tol&Am>tol,'MixedHosts',fifelse(D>1-tol,'DualOnly',fifelse(E>tol,'DualEcM','DualAM')))))]
 A[,`:=`(gT=as.numeric(cls=='MixedHosts'),gDO=as.numeric(cls=='DualOnly'),gDE=as.numeric(cls=='DualEcM'),gDA=as.numeric(cls=='DualAM'))]
 A[,pstar:=fifelse(E+Am>tol,E/(E+Am),0)]
 A[,minority:=pmin(E,Am)/pmax(E+Am,tol)]
 A[,dd:=as.numeric(D>=.5)]
 A[,`:=`(s_EcM=as.numeric(dd==0&pstar>=.8),s_Mid=as.numeric(dd==0&pstar>.2&pstar<.8))]
 A[,SRxMPD:=paste(q0,MPD_bin25,sep='_')];A[,r_mu:=r*mu]
 A[,`:=`(y_N0=log2(normal_NDVI),y_abs=-log2(abs(NDVI-normal_NDVI)),delta=signed_relative_anomaly*100,dabs=(NDVI-normal_NDVI)*100,N0_fine=floor(normal_NDVI*100))]
 br<-c(77.595,178.660,231.571,253.646,321.601,410.022,473.295);A[is.finite(MPD),O:=findInterval(round(MPD,3),br,left.open=TRUE)+1L]
 if(primary)stop('primary=TRUE (an older sample) is not part of the upload package')
 A
}
CON<-function(mx)list('EcM vs AM'=c(g_EcM=1),'Mixed vs AM'=setNames(1,mx),'Mixed vs EcM'=setNames(c(1,-1),c(mx,'g_EcM')),'Mixed vs mean of pure'=setNames(c(1,-.5),c(mx,'g_EcM')))
DEFS<-list(
 fig5=list(x=c('g_EcM','g_Mix'),con=CON('g_Mix')),
 hosts=list(x=c('g_EcM','gT','gDO','gDE','gDA'),con=CON('gT')),
 add_fig5=list(x=c('p_ecm','g_Mix'),con=list('EcM share (additive)'=c(p_ecm=1),'Mixed vs additive'=c(g_Mix=1))),
 add_hosts=list(x=c('pstar','gT','gDO','gDE','gDA'),con=list('EcM share (additive)'=c(pstar=1),'Mixed vs additive'=c(gT=1))),
 dom80=list(x=c('s_EcM','s_Mid','dd'),con=list('EcM vs AM'=c(s_EcM=1),'Mixed vs AM'=c(s_Mid=1),'Mixed vs EcM'=c(s_Mid=1,s_EcM=-1)))
)
fmt_ci<-function(e,l,h,p)sprintf('%+.3f[%+.3f,%+.3f]%s',e,l,h,ifelse(p<.001,'***',ifelse(p<.01,'**',ifelse(p<.05,'*',''))))

diff_two<-function(f1,h1,f2,h2){
 v1<-setNames(numeric(length(f1$b)),names(f1$b));v1[names(h1)]<-h1;v2<-setNames(numeric(length(f2$b)),names(f2$b));v2[names(h2)]<-h2
 cl<-union(rownames(f1$sc),rownames(f2$sc));G<-length(cl)
 a<-drop(f1$sc%*%(f1$bread%*%v1));b<-drop(f2$sc%*%(f2$bread%*%v2))
 A<-setNames(numeric(G),cl);B<-A;A[names(a)]<-a;B[names(b)]<-b
 e<-sum(v1*f1$b)-sum(v2*f2$b);se<-sqrt(sum((A-B)^2)*G/(G-1));cr<-qt(.975,G-1)
 data.table(estimate=e,SE=se,lower=e-cr*se,upper=e+cr*se,p=2*pt(-abs(e/se),G-1))
}
