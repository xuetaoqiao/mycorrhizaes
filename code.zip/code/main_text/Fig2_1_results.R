#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 2a-c
# Results only: fits the models behind Figure 2a, 2b and 2c and writes their results to output/main_text/Fig2/.
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig2_1_prepare_total_data.R (the code used for the paper); the calculations are unchanged.
suppressPackageStartupMessages({library(data.table);library(lme4)})
script<-normalizePath(gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(FALSE),value=TRUE)[1]),fixed=TRUE));here<-dirname(script)
source(file.path(here,'..','00_config.R'))   # upload package: data and output locations
data_dir<-out_dir('main_text','Fig2');setDTthreads(6)
ctr_raw<-c('stand_age_years','density_ha','slope_percent','elevation_m','pre','tem','SPEI_Oct06')
D<-paper2_events()[,c('event_ID','plot_ID','year','eco','q0','EcM_percent','resistance','MPD','phylo_complete','conifer_share','type_group',ctr_raw),with=FALSE]
stopifnot(nrow(D)==363085L,uniqueN(D$plot_ID)==83092L,!anyDuplicated(D$event_ID),all(is.finite(D$resistance)&D$resistance>0))
D[,ty:=fifelse(EcM_percent>=95,'EcM',fifelse(EcM_percent<=5,'AM','Mixed'))];stopifnot(D[ty!='Mixed',max(q0)]==8L,D[ty=='Mixed',min(q0)]==2L)
D[,`:=`(y=log(resistance),ecm=(EcM_percent-50)/50,plot_f=factor(plot_ID))];D[,ecm2:=ecm^2]
fit<-function(f,d)lmer(f,data=d,REML=FALSE,control=lmerControl(optimizer='bobyqa',calc.derivs=FALSE))
fieller<-function(b1,b2,W,crit){A<-b2^2-crit^2*W[2,2];B<- -2*b1*b2+2*crit^2*W[1,2];C<-b1^2-crit^2*W[1,1];disc<-B^2-4*A*C
 if(A<=0||disc<0)return(c(NA_real_,NA_real_));r<-sort(c((-B-sqrt(disc))/(2*A),(-B+sqrt(disc))/(2*A)));c(50-25*r[2],50-25*r[1])}
peak<-function(b1,b2){vx<-50-25*b1/b2;cand<-c(0,100);if(b2<0&&vx>0&&vx<100)cand<-c(cand,vx);xc<-(cand-50)/50;list(best=cand[which.max(b1*xc+b2*xc^2)],vertex=vx)}

D[,`:=`(EcM_bin=pmin(100L,as.integer(ceiling(EcM_percent))),log2_resistance=y/log(2))]
bins<-D[,.(events=.N,plots=uniqueN(plot_ID),mean_EcM=mean(EcM_percent),mean_log2_R=mean(log2_resistance),SD_log2_R=sd(log2_resistance),mean_richness=mean(q0)),keyby=EcM_bin]
stopifnot(nrow(bins)==101L,sum(bins$events)==nrow(D))
fwrite(bins,file.path(data_dir,'panel_a_EcM_bin_summary.csv'))
ma<-fit(y~ecm+ecm2+(1|plot_f),D);ba<-fixef(ma);Va<-as.matrix(vcov(ma))
E<-seq(0,100,by=.1);e<-(E-50)/50;X<-cbind(1,e,e^2);f<-drop(X%*%ba)/log(2);se<-sqrt(pmax(0,rowSums((X%*%Va)*X)))/log(2)
fwrite(data.table(EcM=E,fit_log2_R=f,lower95=f-qnorm(.975)*se,upper95=f+qnorm(.975)*se),file.path(data_dir,'panel_a_quadratic_curve.csv'))
fwrite(data.table(term=names(ba),estimate=ba,se=sqrt(diag(Va))),file.path(data_dir,'panel_a_coefficients.csv'))
vc<-as.data.table(as.table(Va));setnames(vc,c('term1','term2','value'));fwrite(vc,file.path(data_dir,'panel_a_covariance.csv'))
pa<-peak(ba[['ecm']],ba[['ecm2']]);cat('panel a peak',pa$best,'\n');flush.console()

sup<-D[,.(events=.N,plots=uniqueN(plot_ID),EcM_min=min(EcM_percent),EcM_p05=quantile(EcM_percent,.05),EcM_p95=quantile(EcM_percent,.95),EcM_max=max(EcM_percent),
 low_EcM_plots=uniqueN(plot_ID[EcM_percent<=20]),middle_EcM_plots=uniqueN(plot_ID[EcM_percent>20&EcM_percent<80]),high_EcM_plots=uniqueN(plot_ID[EcM_percent>=80]),
 types_present=uniqueN(ty)),keyby=q0]
sup[,support_screen:=low_EcM_plots>=500&high_EcM_plots>=500&types_present==3L]
fwrite(sup,file.path(data_dir,'richness_sample_support.csv'));print(sup)
lv<-sort(unique(D$q0));D[,rich:=factor(q0,levels=lv)]
for(l in lv)set(D,j=paste0('e_L',l),value=D$ecm*(D$q0==l))
for(l in setdiff(lv,1L))set(D,j=paste0('e2_L',l),value=D$ecm2*(D$q0==l))
fb<-reformulate(c('0','rich',paste0('e_L',lv),paste0('e2_L',setdiff(lv,1L)),'(1|plot_f)'),response='y')
mb<-fit(fb,D);bb<-fixef(mb);Vb<-as.matrix(vcov(mb))
show_b<-sup[support_screen==TRUE,q0];stopifnot(identical(as.integer(show_b),2:8))
RB<-rbindlist(lapply(show_b,function(l){nm<-c(paste0('e_L',l),paste0('e2_L',l));b1<-bb[[nm[1]]];b2<-bb[[nm[2]]];W<-Vb[nm,nm];p<-peak(b1,b2);ci<-fieller(b1,b2,W,qnorm(.975))
 data.table(panel='Richness',position=l,level=as.character(l),MPD_value=NA_real_,model='richness_levels',b1=b1,b2=b2,v11=W[1,1],v12=W[1,2],v22=W[2,2],maximum_EcM=p$best,vertex=p$vertex,model_CI_lo=ci[1],model_CI_hi=ci[2],spatial_CI_lo=NA_real_,spatial_CI_hi=NA_real_,
  maximum_type=if(p$best>0&&p$best<100)'Interior mathematical maximum'else'Boundary maximum')}))
RB[,`:=`(panel_mean=mean(maximum_EcM),figure_panel='b',reference_EcM=50)];print(RB[,.(level,maximum_EcM,model_CI_lo,model_CI_hi)]);flush.console()

z<-function(x)(x-mean(x))/sd(x)
P<-D[phylo_complete%in%TRUE&is.finite(MPD),c('plot_ID','year','eco','q0','MPD','EcM_percent','y','ecm','ecm2','conifer_share','type_group',ctr_raw),with=FALSE]
stopifnot(all(P$q0>=2),all(is.finite(P$conifer_share)))
ctr<-paste0('z',seq_along(ctr_raw));for(i in seq_along(ctr_raw))set(P,j=ctr[i],value=z(P[[ctr_raw[i]]]))
P[,`:=`(EcM=EcM_percent,plot_f=factor(plot_ID),year_f=factor(year),eco_f=factor(eco),mpd_key=round(MPD,3),mpd_z=z(MPD),
        comp=fifelse(conifer_share==1,'Conifer',fifelse(conifer_share==0,'Broadleaf','Both')),PJ=type_group%in%'Pinyon / juniper group')]
PJ_value<-253.646
natural<-function(low=100,mid=200,upper=c(400,500,650),split_transition=TRUE,d=P){
 g<-integer(nrow(d));k<-d$mpd_key;m<-d$MPD
 g[m<low]<-1L;g[m>=low&m<mid]<-if(split_transition)3L else 2L
 if(split_transition)g[m>=low&m<mid&d$comp=='Conifer']<-2L
 g[m>=mid&k<PJ_value]<-4L;g[k==PJ_value]<-5L;g[k>PJ_value]<-5L+findInterval(m[k>PJ_value],upper)+1L
 stopifnot(all(g>0L));g}
quantile_groups<-function(k){cuts<-unique(as.numeric(quantile(P$mpd_key,(1:(k-1))/k)));as.integer(cut(P$mpd_key,c(-Inf,cuts,Inf),labels=FALSE,right=TRUE))}
fit_classes<-function(g,d=P,adjusted=FALSE){
 d<-copy(d);d[,cls:=factor(g)]
 f<-if(adjusted)as.formula(paste('y~cls*(ecm+ecm2)+',paste(ctr,collapse='+'),'+(1|plot_f)+(1|year_f)+(1|eco_f)'))else y~cls*(ecm+ecm2)+(1|plot_f)
 m<-fit(f,d);b<-fixef(m);V<-as.matrix(vcov(m))
 rows<-lapply(levels(d$cls),function(k){
  a<-d[cls==k]
  out<-data.table(class_id=as.integer(k),events=nrow(a),plots=uniqueN(a$plot_ID),MPD_min=min(a$MPD),MPD_median=median(a$MPD),MPD_max=max(a$MPD),median_richness=as.numeric(median(a$q0)),
   conifer_only_pct=100*mean(a$comp=='Conifer'),broadleaf_only_pct=100*mean(a$comp=='Broadleaf'),conifer_broadleaf_pct=100*mean(a$comp=='Both'),PJ_type_pct=100*mean(a$PJ),
   plots_EcM_le20=uniqueN(a$plot_ID[a$EcM<=20]),plots_EcM_ge80=uniqueN(a$plot_ID[a$EcM>=80]),events_EcM_100_pct=100*mean(a$EcM>=99.999))
  if(k!=levels(d$cls)[1]&&!all(paste0('cls',k,c(':ecm',':ecm2'))%in%names(b)))return(out)
  H<-matrix(0,2,length(b),dimnames=list(NULL,names(b)));H[1,'ecm']<-1;H[2,'ecm2']<-1
  if(k!=levels(d$cls)[1]){H[1,paste0('cls',k,':ecm')]<-1;H[2,paste0('cls',k,':ecm2')]<-1}
  beta<-drop(H%*%b);W<-H%*%V%*%t(H);p<-peak(beta[1],beta[2]);ci<-fieller(beta[1],beta[2],W,qnorm(.975))
  ex<-range(a$EcM);sl<-function(e0){v<-c(1,2*(e0-50)/50);s<-sum(v*beta);se<-sqrt(drop(t(v)%*%W%*%v));c(pos=pnorm(-s/se),neg=pnorm(s/se))}
  out[,`:=`(b1=beta[1],b2=beta[2],v11=W[1,1],v12=W[1,2],v22=W[2,2],maximum_EcM=p$best,vertex=p$vertex,model_CI_lo=ci[1],model_CI_hi=ci[2],
   p_curvature=2*pnorm(-abs(beta[2]/sqrt(W[2,2]))),p_hump=max(sl(ex[1])['pos'],sl(ex[2])['neg']))]
  out})
 ll<-logLik(m);list(AIC=AIC(m),BIC=BIC(m),params=attr(ll,'df'),classes=rbindlist(rows,fill=TRUE))}
purity<-function(x)x[,sum(events*pmax(conifer_only_pct,broadleaf_only_pct,conifer_broadleaf_pct))/sum(events)]
pass_rule<-function(x)x$plots_EcM_le20>=500&x$plots_EcM_ge80>=500
final<-natural();F9<-fit_classes(final)
labels<-data.table(class_id=1:9,level=c('<100','100-200 conifer','100-200','200-254','254','254-400','400-500','500-524','650'),
 MPD_lo=c(0,100,100,200,253.646,253.646,400,500,650.1),MPD_hi=c(100,200,200,253.646,253.646,400,500,524,650.1),
 composition_group=c('Conifer','Conifer','Broadleaf','Broadleaf','P-J','Conifer + broadleaf','Conifer + broadleaf','Conifer + broadleaf','Conifer + broadleaf'))
CL<-merge(labels,F9$classes,by='class_id');setorder(CL,class_id)
CL[,meets_support:=pass_rule(CL)];CL[,plotted:=meets_support&maximum_EcM>0&maximum_EcM<100]
stopifnot(sum(CL$events)==nrow(P))
fwrite(CL,file.path(data_dir,'panel_c_MPD_classes.csv'));print(CL[,.(level,events,plots,plots_EcM_le20,plots_EcM_ge80,maximum_EcM,vertex,model_CI_lo,model_CI_hi,p_hump,meets_support,plotted)]);flush.console()
cmp<-list()
add_cmp<-function(id,desc,g){r<-fit_classes(g);x<-r$classes;cmp[[length(cmp)+1L]]<<-data.table(scheme=id,description=desc,classes=nrow(x),params=r$params,AIC=r$AIC,BIC=r$BIC,
 composition_purity_pct=purity(x),lowest_class_purity_pct=x[,min(pmax(conifer_only_pct,broadleaf_only_pct,conifer_broadleaf_pct))],classes_failing_support=sum(!pass_rule(x)),events_in_failing_classes_pct=100*x[!pass_rule(x),sum(events)]/nrow(P));invisible(r)}
cont<-fit(y~(ecm+ecm2)*mpd_z+(1|plot_f),P)
cmp[[1]]<-data.table(scheme='Continuous',description='Continuous MPD interaction',classes=NA_integer_,params=attr(logLik(cont),'df'),AIC=AIC(cont),BIC=BIC(cont))
for(k in c(3:10,12))add_cmp(paste0('Q',k),paste0('Equal-frequency ',k,'-quantile groups (ties kept together)'),quantile_groups(k))
add_cmp('Natural_MPD_7','MPD breaks 100, 200, 254, 500, 650',natural(upper=c(500,650),split_transition=FALSE))
add_cmp('Natural_MPD_8','MPD breaks 100, 200, 254, 400, 500, 650',natural(split_transition=FALSE))
add_cmp('Final_no_400','Final classes without the 400 Myr break',natural(upper=c(500,650)))
cmp[[length(cmp)+1L]]<-data.table(scheme='Final',description='MPD breaks 100, 200, 254, 400, 500, 650; 100-200 Myr split into conifer-only and broadleaf-only',classes=9L,params=F9$params,AIC=F9$AIC,BIC=F9$BIC,
 composition_purity_pct=purity(F9$classes),lowest_class_purity_pct=F9$classes[,min(pmax(conifer_only_pct,broadleaf_only_pct,conifer_broadleaf_pct))],classes_failing_support=sum(!pass_rule(F9$classes)),events_in_failing_classes_pct=100*F9$classes[!pass_rule(F9$classes),sum(events)]/nrow(P))
CMP<-rbindlist(cmp,fill=TRUE);CMP[,`:=`(delta_AIC_vs_final=AIC-AIC[scheme=='Final'],delta_BIC_vs_final=BIC-BIC[scheme=='Final'])]
fwrite(CMP,file.path(data_dir,'panel_c_scheme_comparison.csv'));flush.console()
sens<-list(Main=F9$classes)
for(s in list(list('400 to 375',natural(upper=c(375,500,650))),list('400 to 425',natural(upper=c(425,500,650))),list('200 to 198',natural(mid=198)),list('200 to 205',natural(mid=205)),
              list('100 to 90',natural(low=90)),list('100 to 125',natural(low=125)),list('500 to 490',natural(upper=c(400,490,650))),list('500 to 505',natural(upper=c(400,505,650)))))
 sens[[s[[1]]]]<-fit_classes(s[[2]])$classes
sens[['100-200 not split']]<-fit_classes(natural(split_transition=FALSE))$classes
i8<-P$q0<=8;sens[['Richness 2-8']]<-fit_classes(final[i8],P[i8])$classes
sens[['Environment adjusted']]<-fit_classes(final,adjusted=TRUE)$classes
sens[['Each class fitted separately']]<-rbindlist(lapply(1:9,function(k){a<-P[final==k];m<-fit(y~ecm+ecm2+(1|plot_f),a);b<-fixef(m);p<-peak(b[['ecm']],b[['ecm2']]);data.table(class_id=k,events=nrow(a),maximum_EcM=p$best,vertex=p$vertex)}))
SEN<-rbindlist(lapply(names(sens),function(n){x<-sens[[n]];data.table(variant=n,class_id=x$class_id,events=x$events,maximum_EcM=x$maximum_EcM,vertex=x$vertex)}))
SEN<-merge(SEN,labels[,.(class_id,level)],by='class_id');setorder(SEN,variant,class_id);SEN[variant=='100-200 not split'&class_id==2,level:='100-200 pooled']
fwrite(SEN[,.(variant,class_id,level,events,maximum_EcM,vertex)],file.path(data_dir,'panel_c_sensitivity.csv'))
composition_shares<-function(d)d[,.(events=.N,share_pct=100*.N/nrow(P),conifer_only_pct=100*mean(comp=='Conifer'),broadleaf_only_pct=100*mean(comp=='Broadleaf'),conifer_broadleaf_pct=100*mean(comp=='Both'),PJ_type_pct=100*mean(PJ),median_richness=as.numeric(median(q0)))]
bands<-P[,composition_shares(.SD),keyby=.(MPD=5*floor(MPD/5))];bands[,kind:='5-Myr band (lower limit)']
common<-P[,composition_shares(.SD),by=.(MPD=mpd_key)][order(-events)][1:20];common[,kind:='Most common MPD value']
fwrite(rbind(common,bands,use.names=TRUE)[,.(kind,MPD,events,share_pct,conifer_only_pct,broadleaf_only_pct,conifer_broadleaf_pct,PJ_type_pct,median_richness)],file.path(data_dir,'panel_c_MPD_distribution.csv'))
DEC<-copy(P)[,cls:=final][,.(events=.N,mean_ln_R=mean(y)),keyby=.(class_id=cls,EcM_decile=pmin(9L,as.integer(floor(EcM/10)))*10L)]
DEC<-merge(DEC,labels[,.(class_id,level)],by='class_id');setorder(DEC,class_id,EcM_decile);fwrite(DEC[,.(class_id,level,EcM_decile,events,mean_ln_R)],file.path(data_dir,'panel_c_EcM_decile_means.csv'))
A<-CL[plotted==TRUE]
RC<-A[,.(panel='MPD',position=seq_len(.N),level,MPD_value=MPD_median,model='MPD_classes',b1,b2,v11,v12,v22,maximum_EcM,vertex,model_CI_lo,model_CI_hi,spatial_CI_lo=NA_real_,spatial_CI_hi=NA_real_,
 maximum_type=fifelse(maximum_EcM>0&maximum_EcM<100,'Interior mathematical maximum','Boundary maximum'),panel_mean=mean(maximum_EcM),figure_panel='c',reference_EcM=50)]
fwrite(rbind(RB,RC,use.names=TRUE),file.path(data_dir,'panels_bc_lollipop_values.csv'))
fwrite(data.table(model=c('MPD_continuous','MPD_classes'),n=nrow(P),plots=uniqueN(P$plot_ID),AIC=c(AIC(cont),F9$AIC)),file.path(data_dir,'MPD_model_AIC_comparison.csv'))
fwrite(data.table(item=c('total_events','total_plots','MPD_events','MPD_plots','b_levels','c_plotted','panel_a_peak'),
 value=c(nrow(D),uniqueN(D$plot_ID),nrow(P),uniqueN(P$plot_ID),length(show_b),nrow(RC),pa$best)),file.path(data_dir,'sample_counts.csv'))
options(width=220,digits=5);print(CMP[,.(scheme,classes,delta_AIC_vs_final,delta_BIC_vs_final,composition_purity_pct,classes_failing_support)])
print(dcast(SEN,factor(variant,levels=names(sens))~factor(level,levels=labels$level),value.var='maximum_EcM'))
cat('COMPLETE\n')
