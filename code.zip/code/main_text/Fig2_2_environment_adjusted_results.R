#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 2b sensitivity
# Results only: refits the Figure 2b model with seven covariates and three random intercepts (Supporting Information Table S2).
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig2_2_panel_b_environment_adjusted.R (the code used for the paper); the calculations are unchanged.
suppressPackageStartupMessages({library(data.table);library(lme4)})
script<-normalizePath(gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(FALSE),value=TRUE)[1]),fixed=TRUE));here<-dirname(script)
source(file.path(here,'..','00_config.R'))   # upload package: data and output locations
setDTthreads(6)
ctr_raw<-c('stand_age_years','density_ha','slope_percent','elevation_m','pre','tem','SPEI_Oct06')
D<-paper2_events()[,c('event_ID','plot_ID','year','eco','q0','EcM_percent','resistance',ctr_raw),with=FALSE]
stopifnot(nrow(D)==363085L,uniqueN(D$plot_ID)==83092L,all(sapply(ctr_raw,function(v)all(is.finite(D[[v]])))))
D[,`:=`(y=log(resistance),ecm=(EcM_percent-50)/50,plot_f=factor(plot_ID),year_f=factor(year),eco_f=factor(eco))];D[,ecm2:=ecm^2]
ctr<-paste0('z',seq_along(ctr_raw));for(i in seq_along(ctr_raw))set(D,j=ctr[i],value=(D[[ctr_raw[i]]]-mean(D[[ctr_raw[i]]]))/sd(D[[ctr_raw[i]]]))
lv<-sort(unique(D$q0));D[,rich:=factor(q0,levels=lv)]
for(l in lv)set(D,j=paste0('e_L',l),value=D$ecm*(D$q0==l))
for(l in setdiff(lv,1L))set(D,j=paste0('e2_L',l),value=D$ecm2*(D$q0==l))
fb<-reformulate(c('0','rich',paste0('e_L',lv),paste0('e2_L',setdiff(lv,1L)),ctr,'(1|plot_f)','(1|year_f)','(1|eco_f)'),response='y')
m<-lmer(fb,data=D,REML=FALSE,control=lmerControl(optimizer='bobyqa',calc.derivs=FALSE));b<-fixef(m)
peak<-function(b1,b2){vx<-50-25*b1/b2;cand<-c(0,100);if(b2<0&&vx>0&&vx<100)cand<-c(cand,vx);xc<-(cand-50)/50;list(best=cand[which.max(b1*xc+b2*xc^2)],vertex=vx)}
R<-rbindlist(lapply(2:8,function(l){b1<-b[[paste0('e_L',l)]];b2<-b[[paste0('e2_L',l)]];p<-peak(b1,b2);data.table(q0=l,b1=b1,b2=b2,maximum_EcM=p$best,vertex=p$vertex)}))
fwrite(R,file.path(out_dir('main_text','Fig2'),'panel_b_environment_adjusted.csv'));print(R)
cat('COMPLETE\n')
