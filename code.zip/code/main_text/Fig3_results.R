#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 3 (and Supporting Information Table S6)
# Results only: compares the drought resistance of AM and EcM monospecific stands within ecoregions.
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Same calculation as v1_current_full/code/main_text/Fig3_analysis_and_plot.R (sample steps 04 to 08, ecoregion
# means and SDs of log2 resistance, and the paired Wilcoxon test across ecoregions).
here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
source(file.path(here, "..", "00_config.R"))
setDTthreads(4)
out <- out_dir("main_text", "Fig3")

a <- paper2_events()
flow <- list()
record <- function(d, stage) flow[[length(flow) + 1L]] <<- data.table(stage = stage, events = nrow(d), distinct_plots = uniqueN(d$plot_ID))
record(a, "01_study_total_data")
# Stands of pure AM or pure EcM tree species (0% or 100% EcM basal area)
a <- a[EcM_percent %in% c(0, 100)]
a[, guild := fifelse(EcM_percent == 0, "AM", "EcM")]
record(a, "04_pure_AM_or_EcM_guild")
valid_sr <- a[, .(events = .N), by = .(guild, q0)][events >= 10, .(guild, q0)]
a <- a[valid_sr, on = .(guild, q0), nomatch = 0]
record(a, "05_at_least_10_events_per_guild_richness_level")
valid_eco <- a[, .(plots = uniqueN(plot_ID)), by = .(eco, guild)][plots >= 2, .(eco, guild)]
a <- a[valid_eco, on = .(eco, guild), nomatch = 0]
record(a, "06_at_least_2_plots_per_guild_group_before_SR1_filter")
a <- a[q0 == 1]
a[, log2_R := log2(resistance)]
record(a, "07_strict_SR1")

# Ecoregion x mycorrhizal type: mean and SD (n - 1) of log2 resistance, events and distinct plots
s <- a[, .(mean_log2_R = mean(log2_R), sd_log2_R = sd(log2_R), observations = .N,
           distinct_plots = uniqueN(plot_ID)), by = .(region = as.character(eco), guild)]
pairs <- dcast(s[observations > 5], region ~ guild, value.var = c("mean_log2_R", "sd_log2_R", "observations", "distinct_plots"))
pairs <- pairs[is.finite(mean_log2_R_AM) & is.finite(mean_log2_R_EcM)]
a <- a[as.character(eco) %in% pairs$region]
record(a, "08_paired_groups_both_guilds_more_than_5_SR1_events")
counts <- a[, .(total_events = .N, total_distinct_plots = uniqueN(plot_ID)), by = .(region = as.character(eco))]
pairs <- merge(pairs, counts, by = "region", sort = TRUE)
pairs[, delta_log2_EcM_minus_AM := mean_log2_R_EcM - mean_log2_R_AM]
pairs[, direction := fifelse(delta_log2_EcM_minus_AM > 0, "EcM higher", fifelse(delta_log2_EcM_minus_AM < 0, "AM higher", "Equal"))]

# The paired unit is the ecoregion: exact two-sided Wilcoxon signed-rank test (not an event-level test)
w <- wilcox.test(pairs$mean_log2_R_AM, pairs$mean_log2_R_EcM, paired = TRUE, exact = TRUE, alternative = "two.sided")
tests <- data.table(paired_regions = nrow(pairs), EcM_higher = sum(pairs$direction == "EcM higher"),
                    AM_higher = sum(pairs$direction == "AM higher"), Wilcoxon_V = unname(w$statistic),
                    Wilcoxon_two_sided_p = w$p.value)
fwrite(pairs, file.path(out, "Fig3_results_by_ecoregion.csv"))
fwrite(rbindlist(flow), file.path(out, "Fig3_sample_flow.csv"))
fwrite(tests, file.path(out, "Fig3_paired_test.csv"))
stopifnot(nrow(pairs) == 21, nrow(a) == 73682, uniqueN(a$plot_ID) == 13310)
print(tests)
cat("Done:", out, "\n")
