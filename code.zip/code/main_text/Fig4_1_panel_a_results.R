#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Figure 4a
# Results only: fits the richness-resistance regressions of Figure 4a (with plot-clustered standard errors).
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/main_text/Fig4_1_panel_a.R (the code used for the paper); the calculations are unchanged.
suppressPackageStartupMessages({library(data.table);library(jsonlite);library(digest)})
script<-normalizePath(gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE));here<-dirname(script)
source(file.path(here,'..','00_config.R'))   # upload package: data and output locations
out<-out_dir('main_text','Fig4');for(d in c('tables','qa'))dir.create(file.path(out,d),showWarnings=FALSE)
src<-EVENTS_FILE
A<-paper2_events()[,.(event_ID,plot_ID,year,eco,q0,EcM_percentage,Rs_log,species_richness_log)];stopifnot(nrow(A)==363085L,!anyDuplicated(A$event_ID))
A[,type:=fifelse(EcM_percentage>=95,'EcM',fifelse(EcM_percentage<=5,'AM','Mixed EcM and AM'))]
flow<-A[,.(before=.N,removed_SR_above8=sum(q0>8&type!='Mixed EcM and AM')),by=type]
A<-A[type=='Mixed EcM and AM'|q0<=8]
stopifnot(nrow(A)==363085L,A[type=='EcM',.N]==128599L,A[type=='AM',.N]==63205L,A[type=='Mixed EcM and AM',.N]==171281L)
fwrite(flow,file.path(out,'tables/SR_filter_flow.csv'))   # [Upload package] the event table is not copied again
types<-c('Total','EcM','AM','Mixed EcM and AM');REG<-PRED<-SIZES<-SUPPORT<-list()
for(t in types){
 d<-if(t=='Total')A else A[type==t];m<-lm(Rs_log~species_richness_log,data=d);s<-summary(m);b<-coef(m);X<-model.matrix(m)
 n<-nrow(d);G<-uniqueN(d$plot_ID);B<-solve(crossprod(X));score<-rowsum(X*as.numeric(residuals(m)),d$plot_ID,reorder=FALSE)
 V<-B%*%crossprod(score)%*%B*G/(G-1)*(n-1)/(n-2)
 REG[[t]]<-data.table(type=t,n=n,plots=G,intercept=unname(b[1]),slope=unname(b[2]),OLS_F=unname(s$fstatistic[1]),
  df_num=unname(s$fstatistic[2]),df_den=unname(s$fstatistic[3]),OLS_p=s$coefficients[2,4],R_squared=s$r.squared,
  plot_cluster_SE=sqrt(V[2,2]),plot_cluster_p=2*pt(-abs(b[2]/sqrt(V[2,2])),G-1),min_richness=min(d$q0),max_richness=max(d$q0),above_display16=sum(d$Rs_log>16))
 x<-seq(min(d$species_richness_log),max(d$species_richness_log),length.out=180);pn<-predict(m,data.frame(species_richness_log=x),interval='confidence')
 PRED[[t]]<-data.table(type=t,x=x,fit=pn[,1],lower=pn[,2],upper=pn[,3])
 SIZES[[t]]<-data.table(type=t,events=n,plots=G,SR_min=min(d$q0),SR_max=max(d$q0),SR1_events=sum(d$q0==1))
 SUPPORT[[t]]<-d[,.(events=.N,plots=uniqueN(plot_ID)),by=q0][,type:=t]
}
for(nm in c('REG','PRED','SIZES','SUPPORT'))fwrite(rbindlist(get(nm)),file.path(out,'tables',paste0(c(REG='panel_a_regression',PRED='panel_a_prediction',SIZES='panel_a_sample_sizes',SUPPORT='panel_a_support')[[nm]],'.csv')))
write_json(list(source=basename(src),source_sha256=digest(file=src,algo='sha256'),cutoff=95,dominant_SR='1-8',mixed_SR='1-14 (actual2-14)',
 total='Union of the three filtered groups; each event once',events=nrow(A),plots=uniqueN(A$plot_ID)),file.path(out,'qa/input_policy.json'),pretty=TRUE,auto_unbox=TRUE)
print(rbindlist(SIZES));cat('COMPLETE data and panel a\n')
