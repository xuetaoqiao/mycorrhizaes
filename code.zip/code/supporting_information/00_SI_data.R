# paper2 upload package v2_public_anonymized: shared data for the Supporting Information scripts
# Builds data_all (the study total data: 363,085 drought events in 83,092 plots) and its three
# mycorrhizal subsets, with the variable names used by the SI scripts. Sourced by the SI scripts.
#   AM-dominant: EcM basal area <= 5%, species richness 1-8
#   EcM-dominant: EcM basal area >= 95%, species richness 1-8
#   Mixed: all other stands, species richness 2-14
# Resistance Rs is NDVI resistance; Rs_log = log2(Rs).
suppressPackageStartupMessages(library(data.table))
if (!exists("si_code_dir")) stop("Set si_code_dir (the folder of this file) before sourcing 00_SI_data.R.")
here <- si_code_dir; source(file.path(si_code_dir, "..", "00_config.R"))
si_root <- PAPER2_ROOT

ev <- paper2_events()
stopifnot(nrow(ev) == 363085L, uniqueN(ev$plot_ID) == 83092L, !anyDuplicated(ev$event_ID), all(ev$resistance > 0))
ev[, Mycorrhizal.type := fifelse(EcM_percentage >= 95, "EcM-dominant", fifelse(EcM_percentage <= 5, "AM-dominant", "Mixed"))]
stopifnot(all(ev[, (type == "AM") == (Mycorrhizal.type == "AM-dominant")]),
          all(ev[, (type == "EcM") == (Mycorrhizal.type == "EcM-dominant")]),
          ev[Mycorrhizal.type != "Mixed", range(q0)] == c(1L, 8L),
          ev[Mycorrhizal.type == "Mixed", range(q0)] == c(2L, 14L),
          all(ev[q0 == 1, EcM_percentage %in% c(0, 100)]))

data_all <- as.data.frame(ev[, .(
  event_ID, plot_ID, year,
  ECOSUBCD = as.character(eco),
  species_richness = q0,
  EcM_percentage,
  Rs = resistance,
  Rs_log = log2(resistance),
  species_richness_log = log2(q0),
  Mycorrhizal.type
)])
filtered_data_AM     <- data_all[data_all$Mycorrhizal.type == "AM-dominant", ]
filtered_data_EcM    <- data_all[data_all$Mycorrhizal.type == "EcM-dominant", ]
filtered_data_EcM_AM <- data_all[data_all$Mycorrhizal.type == "Mixed", ]
stopifnot(nrow(filtered_data_AM) == 63205L, nrow(filtered_data_EcM) == 128599L, nrow(filtered_data_EcM_AM) == 171281L)
rm(ev)
