#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Supporting Information Figs S4 and S5
# Results only. No figure is drawn.
#   Fig. S4  AM vs EcM monospecific stands (species richness 1): linear mixed model
#            log2(Rs) ~ type + (1 | ecoregion) + (1 | plot) + (1 | year), REML, with estimated marginal
#            means and the AM - EcM contrast (emmeans).
#   Fig. S5  b: OLS of log2(Rs) on log2(species richness), one point per drought event;
#            a: the plot-level mean resistance that is mapped (the map needs plot coordinates).
# Same calculations and output items as v1_current_full/code/supporting_information/Figure_S4 and Figure_S5.
here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
si_code_dir <- here
source(file.path(si_code_dir, "00_SI_data.R"))
suppressPackageStartupMessages({library(lme4); library(lmerTest); library(emmeans)})
options(datatable.optimize = 1L)
out <- out_dir("supporting_information", "figures_results")

# ---- Fig. S4 ----
d <- rbind(transform(filtered_data_AM[filtered_data_AM$species_richness == 1, ], type = "AM"),
           transform(filtered_data_EcM[filtered_data_EcM$species_richness == 1, ], type = "EcM"))
d <- droplevels(transform(d, type = factor(type, levels = c("AM", "EcM")), ECOSUBCD = factor(ECOSUBCD),
                          plot_ID = factor(plot_ID), year = factor(year)))
ss <- as.data.table(d)[, .(n_records = .N, n_plots = uniqueN(plot_ID), n_ecosubcd = uniqueN(ECOSUBCD), n_years = uniqueN(year)), keyby = type]
md <- droplevels(d[is.finite(d$Rs_log), ])
fit <- lmer(Rs_log ~ type + (1 | ECOSUBCD) + (1 | plot_ID) + (1 | year), data = md, REML = TRUE)
emm <- emmeans(fit, ~ type, lmer.df = "satterthwaite")
ct <- as.data.frame(summary(contrast(emm, method = list("AM - EcM" = c(1, -1)), adjust = "none"), infer = c(TRUE, TRUE)))
em <- as.data.frame(confint(emm, level = 0.95))
names(em)[names(em) %in% c("lower.CL", "asymp.LCL")] <- "lower.CL"; names(em)[names(em) %in% c("upper.CL", "asymp.UCL")] <- "upper.CL"
vc <- as.data.frame(VarCorr(fit))
s4 <- rbind(
  data.frame(item = paste0("n_", ss$type), value = ss$n_records, note = paste0("plots = ", ss$n_plots, "; ecoregions = ", ss$n_ecosubcd, "; years = ", ss$n_years)),
  data.frame(item = paste0("EMM_", em$type), value = em$emmean, note = sprintf("95%% CI %.3f to %.3f", em$lower.CL, em$upper.CL)),
  data.frame(item = "AM_minus_EcM", value = ct$estimate,
             note = sprintf("SE %.4f; 95%% CI %.3f to %.3f; df %s; t or z %.2f; p %.3g", ct$SE, ct[[grep("lower|LCL", names(ct))[1]]],
                            ct[[grep("upper|UCL", names(ct))[1]]], format(ct$df), ct[[grep("ratio", names(ct))[1]]], ct$p.value)),
  data.frame(item = paste0("SD_random_", vc$grp), value = vc$sdcor, note = "random-intercept SD (REML)"),
  data.frame(item = "singular_fit", value = as.numeric(isSingular(fit, tol = 1e-4)), note = "1 = singular"))
stopifnot(sum(ss$n_records) == 75730L)
write.csv(s4, file.path(out, "FigS4_monospecific_AM_vs_EcM_statistics.csv"), row.names = FALSE)
print(s4)

# ---- Fig. S5 ----
D <- as.data.table(data_all)
P <- D[, .(Rs = mean(Rs, na.rm = TRUE), species_richness = round(mean(species_richness, na.rm = TRUE), 0)), keyby = plot_ID]
P[, `:=`(Rs_log = log2(Rs), species_richness_log = log2(species_richness))]
E <- D[, .(Rs = mean(Rs, na.rm = TRUE), species_richness = round(mean(species_richness, na.rm = TRUE), 0)), keyby = .(plot_ID, year)]
E[, `:=`(Rs_log = log2(Rs), species_richness_log = log2(species_richness))]
m <- lm(Rs_log ~ species_richness_log, data = E); sm <- summary(m); cf <- sm$coefficients
stopifnot(nrow(P) == 83092L, nrow(E) == 363085L, max(E$Rs_log) < 25.1, min(E$Rs_log) > 0)
s5 <- data.frame(
  item = c("plots_mapped", "events_regression", "slope_beta", "slope_SE", "intercept", "F", "df1", "df2", "p", "R_squared",
           "map_log2_mean_R_min", "map_log2_mean_R_max"),
  value = c(nrow(P), nrow(E), cf["species_richness_log", "Estimate"], cf["species_richness_log", "Std. Error"], cf["(Intercept)", "Estimate"],
            sm$fstatistic[1], sm$fstatistic[2], sm$fstatistic[3], cf["species_richness_log", "Pr(>|t|)"], sm$r.squared,
            min(P$Rs_log), max(P$Rs_log)))
write.csv(s5, file.path(out, "FigS5_resistance_and_richness_statistics.csv"), row.names = FALSE)
print(s5)
cat("Done:", out, "\n")
