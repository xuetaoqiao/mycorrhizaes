#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Supporting Information Figs S6, S7 and S8
# Results only: these three figures plot tables computed by main_text/Fig5_results.R (run it first).
# This script writes, for each figure, the rows that the figure shows. No figure is drawn.
here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
source(file.path(here, "..", "00_config.R"))
tab <- file.path(OUT_DIR, "main_text", "Fig5", "tables")
if (!dir.exists(tab)) stop("Run main_text/Fig5_results.R first.")
rt <- function(n) fread(file.path(tab, paste0(n, ".csv")))
out <- out_dir("supporting_information", "figures_results")
wt <- function(x, f) { fwrite(x, file.path(out, f)); cat("Wrote", f, nrow(x), "rows\n") }
effects <- c("EcM vs AM", "Mixed vs AM", "Mixed vs EcM")
soil_variant <- function(v) grepl("soil|clay|bulk|nitrogen|\\bpH\\b", v, ignore.case = TRUE)

# Fig. S6: sample support and host MPD structure
wt(rt("support_by_richness")[sample == "Total data"], "FigS6_events_and_plots_by_richness_and_type.csv")
wt(rt("composition_by_richness"), "FigS6_composition_by_richness.csv")
wt(rt("MPD_hist_by_class_clade"), "FigS6_MPD_distribution_by_type_and_clade.csv")

# Fig. S7: robustness of the differences among mycorrhizal types
wt(rt("alternative_definitions")[contrast %in% effects], "FigS7_alternative_type_definitions.csv")
wt(rt("variants")[contrast %in% effects & !soil_variant(variant)], "FigS7_sample_and_covariate_variants.csv")
wt(rt("slopes_richness")[contrast %in% effects], "FigS7_slopes_per_doubling_of_richness.csv")
wt(rt("ecoregion_meta"), "FigS7_pooled_across_ecoregions.csv")

# Fig. S8: host MPD sensitivity
wt(rt("mpd_flexible_controls")[contrast %in% effects], "FigS8_MPD_controls.csv")
wt(rt("EcM_split_by_MPD")[subset == "All"], "FigS8_EcM_split_by_MPD.csv")
wt(rt("natural_experiment_same_MPD"), "FigS8_two_species_stands_identical_MPD.csv")
wt(rt("sizes_per_SD"), "FigS8_effects_per_SD.csv")
cat("Done:", out, "\n")
