#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Supporting Information Figs S1, S2 and S3
# Results only: the counts and means shown in these figures. No figure is drawn.
#   Fig. S1b  plots per ecoregion (the map in Fig. S1a needs plot coordinates, which are not in the anonymized data)
#   Fig. S2   mean and SD of species richness in each EcM class: 0%, then (k - 1, k] for k = 1, ..., 100
#   Fig. S3   drought events per species-richness level and mycorrhizal type; mean richness per type
# Same calculations as v1_current_full/code/supporting_information/Figure_S1, S2 and S3.
here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
si_code_dir <- here
source(file.path(si_code_dir, "00_SI_data.R"))
options(datatable.optimize = 1L)   # base mean() and sd() in each group, as in the figure scripts
out <- out_dir("supporting_information", "figures_results")
D <- as.data.table(data_all)

# Fig. S1b: each plot belongs to one ecoregion
s1 <- D[, .(plots = uniqueN(plot_ID), events = .N), keyby = ECOSUBCD]
stopifnot(sum(s1$plots) == 83092L, sum(s1$events) == 363085L)
fwrite(s1, file.path(out, "FigS1_plots_by_ecoregion.csv"))

# Fig. S2: error bars are +/- 1 SD
D[, EcM_class := fifelse(EcM_percentage == 0, 0, ceiling(EcM_percentage))]
s2 <- D[, .(mean_species_richness = mean(species_richness), sd_species_richness = sd(species_richness), events = .N), keyby = EcM_class]
stopifnot(nrow(s2) == 101L, sum(s2$events) == 363085L)
fwrite(s2, file.path(out, "FigS2_mean_richness_by_EcM_class.csv"))

# Fig. S3: bars count drought events (not plots); dashed lines are the mean richness of each type
s3 <- D[, .(events = .N), keyby = .(Mycorrhizal.type, species_richness)]
s3m <- D[, .(mean_species_richness = mean(species_richness), events = .N), keyby = Mycorrhizal.type]
stopifnot(sum(s3$events) == 363085L)
fwrite(s3, file.path(out, "FigS3_events_by_richness_and_type.csv"))
fwrite(s3m, file.path(out, "FigS3_mean_richness_by_type.csv"))
cat("Done:", out, "\n")
