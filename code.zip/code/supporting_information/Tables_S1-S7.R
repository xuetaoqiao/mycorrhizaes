#!/usr/bin/env Rscript
# paper2 upload package v2_public_anonymized: Supporting Information Tables S1-S7
# Results only: assembles Tables S1 to S7 (CSV) from the main-text results (run the main-text scripts first).
# No figure is drawn. The input is the deposited event table, read by ../00_config.R.
# Derived from v1_current_full/code/supporting_information/Tables_S1-S7_SI_tables.R (the code used for the paper); the calculations are unchanged.
# ------------------------------------------------------------
#
# ------------------------------------------------------------
rm(list = ls())
si_code_dir <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
source(file.path(si_code_dir, "00_SI_data.R"))
suppressPackageStartupMessages(library(data.table))
tab_dir <- out_dir("supporting_information", "tables")
f2 <- function(f) fread(file.path(OUT_DIR, "main_text", "Fig2", f))
wt <- function(x, f) { fwrite(x, file.path(tab_dir, f), bom = TRUE); cat("Wrote", f, nrow(x), "rows\n") }
r1 <- function(x) ifelse(is.na(x), "", formatC(x, format = "f", digits = 1))
pv <- function(p) ifelse(p < 0.001, "< 0.001", formatC(p, format = "f", digits = 3))
peak_txt <- function(m, v) ifelse(abs(m - v) > 1e-6 & m == 100, "100 (boundary)", r1(m))
ci_txt <- function(lo, hi) ifelse(is.na(lo) | is.na(hi), "", paste0(r1(lo), " to ", r1(hi)))
types <- c("AM-dominant", "EcM-dominant", "Mixed")

D <- as.data.table(data_all)
lv <- D[, .(events = .N, plots = uniqueN(plot_ID)), keyby = .(species_richness, Mycorrhizal.type)]
chk <- fread(file.path(OUT_DIR, "main_text", "Fig5", "tables", "support_by_richness.csv"))[sample == "Total data"]
chk[, Mycorrhizal.type := c(AM = "AM-dominant", EcM = "EcM-dominant", Mixed = "Mixed")[ty]]
m <- merge(lv, chk, by.x = c("species_richness", "Mycorrhizal.type"), by.y = c("q0", "Mycorrhizal.type"))
stopifnot(nrow(m) == nrow(lv), nrow(chk) == nrow(lv), all(m$events.x == m$events.y), all(m$plots.x == m$plots.y))
w <- dcast(lv, species_richness ~ Mycorrhizal.type, value.var = c("events", "plots"))
al <- D[, .(all_events = .N, all_plots = uniqueN(plot_ID)), keyby = species_richness]
w <- merge(w, al, by = "species_richness")
tot <- D[, .(events = .N, plots = uniqueN(plot_ID)), by = Mycorrhizal.type]
S1 <- rbind(
  w[, .(`Species richness (S)` = as.character(species_richness),
        `AM-dominant events` = `events_AM-dominant`, `AM-dominant plots` = `plots_AM-dominant`,
        `EcM-dominant events` = `events_EcM-dominant`, `EcM-dominant plots` = `plots_EcM-dominant`,
        `Mixed events` = events_Mixed, `Mixed plots` = plots_Mixed,
        `All events` = all_events, `All plots` = all_plots)],
  data.table(`Species richness (S)` = "All levels",
             `AM-dominant events` = tot[Mycorrhizal.type == types[1], events], `AM-dominant plots` = tot[Mycorrhizal.type == types[1], plots],
             `EcM-dominant events` = tot[Mycorrhizal.type == types[2], events], `EcM-dominant plots` = tot[Mycorrhizal.type == types[2], plots],
             `Mixed events` = tot[Mycorrhizal.type == types[3], events], `Mixed plots` = tot[Mycorrhizal.type == types[3], plots],
             `All events` = nrow(D), `All plots` = uniqueN(D$plot_ID)))
stopifnot(S1[`Species richness (S)` == "All levels", `All events`] == 363085L, S1[`Species richness (S)` == "All levels", `All plots`] == 83092L)
wt(S1, "Table_S1_sample_sizes_by_type_and_richness.csv")

sup <- f2("richness_sample_support.csv")
lol <- f2("panels_bc_lollipop_values.csv")[panel == "Richness", .(q0 = as.integer(level), maximum_EcM, vertex, model_CI_lo, model_CI_hi)]
adj <- f2("panel_b_environment_adjusted.csv")[, .(q0, adj_max = maximum_EcM, adj_vertex = vertex)]
S2 <- merge(merge(sup, lol, by = "q0", all.x = TRUE), adj, by = "q0", all.x = TRUE)
stopifnot(nrow(S2) == 14L, sum(S2$events) == 363085L, identical(S2[support_screen == TRUE, q0], 2:8), all(!is.na(S2[q0 %in% 2:8, maximum_EcM])))
S2 <- S2[, .(`Species richness (S)` = q0, `Drought events` = events, `Plots` = plots,
             `Plots with EcM <= 20%` = low_EcM_plots, `Plots with 20% < EcM < 80%` = middle_EcM_plots, `Plots with EcM >= 80%` = high_EcM_plots,
             `Mycorrhizal types present` = types_present,
             `Meets support rule` = fifelse(support_screen, "Yes", "No"),
             `EcM percentage at highest resistance (%)` = fifelse(q0 == 1, "Not estimated (0% and 100% only)", fifelse(support_screen, peak_txt(maximum_EcM, vertex), "Not shown")),
             `Model 95% CI (%)` = fifelse(support_screen, ci_txt(model_CI_lo, model_CI_hi), ""),
             `With covariates and random intercepts (%)` = fifelse(support_screen, peak_txt(adj_max, adj_vertex), ""))]
wt(S2, "Table_S2_richness_levels_support_and_peaks.csv")

cl <- f2("panel_c_MPD_classes.csv")
stopifnot(nrow(cl) == 9L, sum(cl$events) == 238411L)
cls_lab <- c(`1` = "< 100", `2` = "100 to 200", `3` = "100 to 200", `4` = "200 to 254", `5` = "254 (single value)",
             `6` = "254 to 400", `7` = "400 to 500", `8` = "500 to 524", `9` = "650 (single value)")
comp_lab <- c(`1` = "Conifer", `2` = "Conifer only", `3` = "Broadleaf only", `4` = "Broadleaf", `5` = "P–J",
              `6` = "Conifer + broadleaf", `7` = "Conifer + broadleaf", `8` = "Conifer + broadleaf", `9` = "Conifer + broadleaf")
S3 <- cl[, .(`Host MPD class (Myr)` = cls_lab[as.character(class_id)], `Host composition` = comp_lab[as.character(class_id)],
             `Drought events` = events, `Plots` = plots, `Median species richness` = median_richness,
             `P–J stands (% of events)` = r1(PJ_type_pct),
             `Plots with EcM <= 20%` = plots_EcM_le20, `Plots with EcM >= 80%` = plots_EcM_ge80,
             `Meets support rule` = fifelse(meets_support, "Yes", "No"),
             `EcM percentage at highest resistance (%)` = peak_txt(maximum_EcM, vertex),
             `Model 95% CI (%)` = ci_txt(model_CI_lo, model_CI_hi),
             `P (interior maximum)` = pv(p_hump),
             `Shown in Fig. 2c` = fifelse(plotted, "Yes", "No"))]
wt(S3, "Table_S3_MPD_classes_and_peaks.csv")

sc <- f2("panel_c_scheme_comparison.csv")
sc_lab <- function(s, d) fcase(s == "Continuous", "Continuous MPD (no classes)",
                              grepl("^Q[0-9]+$", s), paste0("Equal-frequency, ", sub("^Q", "", s), " quantiles"),
                              s == "Natural_MPD_7", "MPD gaps: 100, 200, 254, 500, 650 Myr",
                              s == "Natural_MPD_8", "MPD gaps: 100, 200, 254, 400, 500, 650 Myr",
                              s == "Final_no_400", "Final classes without the 400 Myr break",
                              s == "Final", "Final classes (Fig. 2c)")
S4 <- sc[, .(`Grouping scheme` = sc_lab(scheme, description), `Classes` = fifelse(is.na(classes), "", as.character(classes)),
             `Parameters` = params,
             `Delta AIC` = r1(delta_AIC_vs_final), `Delta BIC` = r1(delta_BIC_vs_final),
             `Composition purity (%)` = r1(composition_purity_pct), `Lowest class purity (%)` = r1(lowest_class_purity_pct),
             `Classes failing support rule` = fifelse(is.na(classes_failing_support), "", as.character(classes_failing_support)),
             `Events in failing classes (%)` = r1(events_in_failing_classes_pct))]
stopifnot(sc[scheme == "Final", delta_AIC_vs_final] == 0)
wt(S4, "Table_S4_MPD_grouping_schemes.csv")

se <- f2("panel_c_sensitivity.csv")
col_lv <- c("100-200", "200-254", "254", "254-400", "400-500", "500-524", "650")
col_lb <- c("100 to 200 Broadleaf", "200 to 254 Broadleaf", "254 P–J", "254 to 400 Conifer + broadleaf",
            "400 to 500 Conifer + broadleaf", "500 to 524 Conifer + broadleaf", "650 Conifer + broadleaf")
se[level == "100-200 pooled", level := "100-200"]
var_lv <- c("Main", "400 to 375", "400 to 425", "200 to 198", "200 to 205", "100 to 90", "100 to 125", "500 to 490", "500 to 505",
            "100-200 not split", "Richness 2-8", "Each class fitted separately", "Environment adjusted")
var_lb <- c("Main (Fig. 2c)", "400 Myr break moved to 375", "400 Myr break moved to 425", "200 Myr break moved to 198", "200 Myr break moved to 205",
            "100 Myr break moved to 90", "100 Myr break moved to 125", "500 Myr break moved to 490", "500 Myr break moved to 505",
            "100 to 200 Myr not split by composition", "Stands with 2 to 8 species only", "Each class fitted separately",
            "With covariates and random intercepts")
stopifnot(setequal(unique(se$variant), var_lv))
se <- se[level %in% col_lv]
se[, txt := peak_txt(maximum_EcM, vertex)]
S5 <- dcast(se, variant ~ factor(level, col_lv), value.var = "txt")
S5 <- S5[match(var_lv, variant)][, variant := var_lb]
setnames(S5, c("Variant", col_lb))
wt(S5, "Table_S5_peak_sensitivity.csv")

eco_names <- c("211" = "Northeastern Mixed Forest", "212" = "Laurentian Mixed Forest", "221" = "Eastern Broadleaf Forest",
  "222" = "Midwest Broadleaf Forest", "223" = "Central Interior Broadleaf Forest", "231" = "Southeastern Mixed Forest",
  "232" = "Outer Coastal Plain Mixed Forest", "234" = "Lower Mississippi Riverine Forest", "242" = "Pacific Lowland Mixed Forest",
  "251" = "Prairie Parkland (Temperate)", "255" = "Prairie Parkland (Subtropical)", "261" = "California Coastal Chaparral",
  "262" = "California Dry Steppe", "263" = "California Coastal Steppe and Forest", "313" = "Colorado Plateau Semidesert",
  "315" = "Southwest Plateau and Plains Dry Steppe and Shrub", "321" = "Chihuahuan Semidesert", "322" = "American Semidesert and Desert",
  "331" = "Great Plains, Palouse Dry Steppe", "332" = "Great Plains Steppe", "333" = "Northern Rocky Mountain Forest",
  "334" = "Black Hills Coniferous Forest", "341" = "Intermountain Semidesert and Desert", "342" = "Intermountain Semidesert")
er <- fread(file.path(OUT_DIR, "main_text", "Fig3", "Fig3_results_by_ecoregion.csv"))
pt <- fread(file.path(OUT_DIR, "main_text", "Fig3", "Fig3_paired_test.csv"))
stopifnot(nrow(er) == 21L, pt$paired_regions == 21L, pt$EcM_higher == sum(er$delta_log2_EcM_minus_AM > 0),
          all(as.character(er$region) %in% names(eco_names)))
f2d <- function(x) formatC(x, format = "f", digits = 2)
S6 <- er[, .(`Ecoregion` = as.character(region), `Name` = eco_names[as.character(region)],
             `AM: mean log2 Rs (SD)` = paste0(f2d(mean_log2_R_AM), " (", f2d(sd_log2_R_AM), ")"),
             `AM: events` = observations_AM, `AM: plots` = distinct_plots_AM,
             `EcM: mean log2 Rs (SD)` = paste0(f2d(mean_log2_R_EcM), " (", f2d(sd_log2_R_EcM), ")"),
             `EcM: events` = observations_EcM, `EcM: plots` = distinct_plots_EcM,
             `EcM minus AM` = f2d(delta_log2_EcM_minus_AM),
             `Higher` = sub(" higher", "", direction))]
wt(S6, "Table_S6_monospecific_stands_by_ecoregion.csv")
cat(sprintf("Table S6 note: EcM higher in %d of %d ecoregions; Wilcoxon signed-rank V = %s, P = %.4f\n", pt$EcM_higher, pt$paired_regions, pt$Wilcoxon_V, pt$Wilcoxon_two_sided_p))

f4 <- function(f) fread(file.path(OUT_DIR, "main_text", "Fig4", "tables", f))
co <- f4("panel_c_standardized_coefficients.csv")
vif <- rbindlist(lapply(c("AM", "EcM", "Mixed_EcM_and_AM", "Total"), function(k)
  fread(file.path(OUT_DIR, "main_text", "Fig4", "tables", paste0(k, "_VIF.csv")))))
co <- merge(co, vif, by.x = c("type", "variable"), by.y = c("type", "variable"), all.x = TRUE, sort = FALSE)
stopifnot(nrow(co) == 34L, !anyNA(co$VIF), max(co$VIF) < 5)
mod_lab <- c(AM = "AM-dominant", EcM = "EcM-dominant", `Mixed EcM and AM` = "Mixed", Total = "Total dataset")
var_ord <- c("species_richness_log", "EcM_dominant", "Mixed_type", "STDAGE", "DENSITY", "SLOPE", "ELEV", "pre", "tem", "SPEI")
var_lab <- c(species_richness_log = "Species richness (log2)", EcM_dominant = "EcM-dominant (vs AM-dominant)", Mixed_type = "Mixed (vs AM-dominant)",
             STDAGE = "Stand age", DENSITY = "Stand density", SLOPE = "Slope", ELEV = "Elevation",
             pre = "Growing-season precipitation", tem = "Growing-season temperature", SPEI = "Drought intensity (SPEI)")
n4 <- f4("panel_a_regression.csv")[, .(type, n, plots)]
co <- merge(co, n4, by = "type")
co[, `:=`(mo = match(type, c("AM", "EcM", "Mixed EcM and AM", "Total")), vo = match(variable, var_ord))]
setorder(co, mo, vo)
f3 <- function(x) formatC(x, format = "f", digits = 3)
S7 <- co[, .(`Model` = mod_lab[type], `Drought events` = n, `Plots` = plots,
             `Predictor` = var_lab[variable], `Driver group` = driver,
             `Standardized coefficient` = f3(estimate), `SE` = f3(SE),
             `95% CI` = paste0(f3(lower95), " to ", f3(upper95)), `P` = pv(p_Wald),
             `VIF` = formatC(VIF, format = "f", digits = 2))]
wt(S7, "Table_S7_multivariable_model_coefficients.csv")

cat("Done: Tables S1 to S7 in", tab_dir, "\n")
