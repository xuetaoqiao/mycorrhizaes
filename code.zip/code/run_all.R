#!/usr/bin/env Rscript
# Runs the scripts of v2_public_anonymized/code in order, each in its own R process. No figure is drawn.
# Usage (from the package folder or any other folder):  Rscript code/run_all.R          # main text, then Supporting Information
#                           Rscript code/run_all.R main     # main text only
#                           Rscript code/run_all.R si       # Supporting Information only (needs the main-text results)
# Results: output/ (CSV files); one log per script in output/logs/.
here <- local({
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) dirname(normalizePath(gsub("~+~", " ", sub("^--file=", "", a[1]), fixed = TRUE)))
  else if (!is.null(sys.frames()[[1]]$ofile)) dirname(normalizePath(sys.frames()[[1]]$ofile))
  else getwd()
})
part <- commandArgs(TRUE); part <- if (length(part)) part[1] else "all"
main <- file.path("main_text", c("Fig2_1_results.R", "Fig2_2_environment_adjusted_results.R", "Fig3_results.R",
                                 "Fig4_1_panel_a_results.R", "Fig4_2_panels_b_c_results.R", "Fig5_results.R"))
si <- file.path("supporting_information", c("FigS1-S3_results.R", "FigS4-S5_results.R", "FigS6-S8_results.R", "Tables_S1-S7.R"))
scripts <- switch(part, all = c(main, si), main = main, si = si, stop("argument must be main, si or empty"))
out <- Sys.getenv("PAPER2_OUT", file.path(here, "..", "output"))
logs <- file.path(out, "logs"); dir.create(logs, recursive = TRUE, showWarnings = FALSE)
for (s in scripts) {
  t0 <- Sys.time(); log <- file.path(logs, sub("[.]R$", ".log", basename(s)))
  rc <- system2(file.path(R.home("bin"), "Rscript"), shQuote(file.path(here, s)), stdout = log, stderr = log)
  cat(sprintf("%-55s %-6s %5.1f min\n", s, if (rc == 0) "ok" else "FAILED", as.numeric(difftime(Sys.time(), t0, units = "mins"))))
  if (rc != 0) stop(s, " failed; see ", normalizePath(log))
}
cat("Done. Results are in", normalizePath(out), "\n")
